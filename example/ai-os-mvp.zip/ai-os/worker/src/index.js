import { UserVault } from './UserVault.js';

export { UserVault };

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, CF-Access-Jwt-Assertion',
};

export default {
  async fetch(request, env, ctx) {
    // Handle CORS preflight
    if (request.method === 'OPTIONS') {
      return new Response(null, { headers: CORS_HEADERS });
    }

    const url = new URL(request.url);

    // Health check (no auth needed)
    if (url.pathname === '/health') {
      return respond({ status: 'ok', timestamp: new Date().toISOString() });
    }

    // Validate Cloudflare Access JWT
    const authResult = await validateAccess(request, env);
    if (!authResult.ok) {
      return respond({ error: 'Unauthorized' }, 401);
    }

    // All requests route to the single MASTER Durable Object
    if (url.pathname.startsWith('/api/')) {
      const doPath = url.pathname.replace('/api', '');
      const doUrl = new URL(request.url);
      doUrl.pathname = doPath;

      const stub = env.USER_VAULT.get(
        env.USER_VAULT.idFromName('MASTER')
      );

      const doRequest = new Request(doUrl.toString(), {
        method: request.method,
        headers: request.headers,
        body: ['GET', 'HEAD'].includes(request.method) ? null : request.body,
      });

      const doResponse = await stub.fetch(doRequest);
      const data = await doResponse.json();

      return respond(data, doResponse.status);
    }

    return respond({ error: 'Not found' }, 404);
  }
};

/**
 * Validate Cloudflare Access JWT
 * In dev mode (no CF_ACCESS_AUD set), bypass auth
 */
async function validateAccess(request, env) {
  // Dev bypass — remove before production
  if (!env.CF_ACCESS_AUD) {
    console.warn('CF_ACCESS_AUD not set — running in dev mode, auth bypassed');
    return { ok: true };
  }

  const jwt = request.headers.get('Cf-Access-Jwt-Assertion');
  if (!jwt) return { ok: false };

  try {
    // Fetch Cloudflare Access public keys
    const certsUrl = `https://${env.CF_ACCESS_TEAM_DOMAIN}/cdn-cgi/access/certs`;
    const certsResponse = await fetch(certsUrl);
    const certs = await certsResponse.json();

    // Decode JWT header to get kid
    const [headerB64] = jwt.split('.');
    const header = JSON.parse(atob(headerB64));
    const key = certs.keys.find(k => k.kid === header.kid);
    if (!key) return { ok: false };

    // Import public key and verify
    const cryptoKey = await crypto.subtle.importKey(
      'jwk', key,
      { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' },
      false, ['verify']
    );

    const [, payloadB64, sigB64] = jwt.split('.');
    const signingInput = `${headerB64}.${payloadB64}`;
    const signature = base64UrlDecode(sigB64);
    const data = new TextEncoder().encode(signingInput);

    const valid = await crypto.subtle.verify(
      'RSASSA-PKCS1-v1_5', cryptoKey, signature, data
    );

    if (!valid) return { ok: false };

    // Verify audience
    const payload = JSON.parse(atob(payloadB64));
    if (payload.aud !== env.CF_ACCESS_AUD) return { ok: false };

    // Verify expiry
    if (payload.exp < Math.floor(Date.now() / 1000)) return { ok: false };

    return { ok: true, email: payload.email };
  } catch (e) {
    console.error('JWT validation error:', e);
    return { ok: false };
  }
}

function base64UrlDecode(str) {
  const base64 = str.replace(/-/g, '+').replace(/_/g, '/');
  const padded = base64.padEnd(base64.length + (4 - base64.length % 4) % 4, '=');
  const binary = atob(padded);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes.buffer;
}

function respond(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'Content-Type': 'application/json',
      ...CORS_HEADERS,
    }
  });
}
