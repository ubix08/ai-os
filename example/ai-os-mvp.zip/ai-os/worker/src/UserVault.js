import { SCHEMA, DEFAULT_PROMPTS } from './schema.js';
import { buildPrompt, buildStationContext } from './promptEngine.js';
import { callGemini, callGeminiWithFiles, uploadToGeminiFileAPI } from './geminiProxy.js';

function uuid() {
  return crypto.randomUUID();
}

export class UserVault {
  constructor(state, env) {
    this.state = state;
    this.env = env;
    this.sql = state.storage.sql;
  }

  async initialize() {
    // Run schema migrations
    this.sql.exec(SCHEMA);

    // Seed default prompts if empty
    const existing = this.sql.exec('SELECT COUNT(*) as count FROM prompt_templates').one();
    if (existing.count === 0) {
      for (const p of DEFAULT_PROMPTS) {
        this.sql.exec(
          `INSERT OR IGNORE INTO prompt_templates 
           (id, station, label, system_block, context_block, logic_block, constraints_block, output_schema)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
          p.id, p.station, p.label, p.system_block,
          p.context_block, p.logic_block, p.constraints_block, p.output_schema
        );
      }
    }
  }

  async fetch(request) {
    await this.initialize();

    const url = new URL(request.url);
    const path = url.pathname;
    const method = request.method;

    try {
      // ── Vault Profile ──────────────────────────────────────────
      if (path === '/vault/profile' && method === 'GET') {
        return this.getProfile();
      }
      if (path === '/vault/profile' && method === 'POST') {
        const body = await request.json();
        return this.saveProfile(body);
      }

      // ── Prompt Templates ───────────────────────────────────────
      if (path === '/vault/prompts' && method === 'GET') {
        return this.getPrompts();
      }
      if (path.startsWith('/vault/prompts/') && method === 'PUT') {
        const id = path.split('/').pop();
        const body = await request.json();
        return this.updatePrompt(id, body);
      }
      if (path === '/vault/prompts/reset' && method === 'POST') {
        return this.resetPrompts();
      }

      // ── Files ──────────────────────────────────────────────────
      if (path === '/vault/files' && method === 'GET') {
        return this.getFiles();
      }
      if (path === '/vault/files' && method === 'POST') {
        const formData = await request.formData();
        return this.uploadFile(formData);
      }
      if (path.startsWith('/vault/files/') && method === 'DELETE') {
        const id = path.split('/').pop();
        return this.deleteFile(id);
      }

      // ── Pipeline Sessions ──────────────────────────────────────
      if (path === '/pipeline/sessions' && method === 'GET') {
        return this.getSessions();
      }
      if (path === '/pipeline/sessions' && method === 'POST') {
        const body = await request.json();
        return this.createSession(body);
      }
      if (path.match(/^\/pipeline\/sessions\/[^/]+$/) && method === 'GET') {
        const id = path.split('/').pop();
        return this.getSession(id);
      }
      if (path.match(/^\/pipeline\/sessions\/[^/]+$/) && method === 'DELETE') {
        const id = path.split('/').pop();
        return this.deleteSession(id);
      }

      // ── Station Execution ──────────────────────────────────────
      if (path.match(/^\/pipeline\/sessions\/[^/]+\/station\/\d+$/) && method === 'POST') {
        const parts = path.split('/');
        const sessionId = parts[3];
        const stationNum = parseInt(parts[5]);
        return this.executeStation(sessionId, stationNum);
      }

      return json({ error: 'Not found' }, 404);
    } catch (e) {
      console.error('DO Error:', e);
      return json({ error: e.message }, 500);
    }
  }

  // ── Profile ──────────────────────────────────────────────────────

  getProfile() {
    const row = this.sql.exec('SELECT * FROM vault_profile WHERE id = 1').one();
    if (!row) {
      return json({ onboarding_done: 0 });
    }
    return json({
      ...row,
      brand_tone: row.brand_tone ? JSON.parse(row.brand_tone) : []
    });
  }

  saveProfile(data) {
    const brandTone = Array.isArray(data.brand_tone)
      ? JSON.stringify(data.brand_tone)
      : data.brand_tone || '[]';

    this.sql.exec(
      `INSERT INTO vault_profile (id, business_name, website_url, linkedin, twitter,
        value_prop, target_audience, anti_persona, brand_tone, onboarding_done, updated_at)
       VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
       ON CONFLICT(id) DO UPDATE SET
         business_name = excluded.business_name,
         website_url = excluded.website_url,
         linkedin = excluded.linkedin,
         twitter = excluded.twitter,
         value_prop = excluded.value_prop,
         target_audience = excluded.target_audience,
         anti_persona = excluded.anti_persona,
         brand_tone = excluded.brand_tone,
         onboarding_done = excluded.onboarding_done,
         updated_at = excluded.updated_at`,
      data.business_name || '',
      data.website_url || '',
      data.linkedin || '',
      data.twitter || '',
      data.value_prop || '',
      data.target_audience || '',
      data.anti_persona || '',
      brandTone,
      data.onboarding_done ? 1 : 0
    );
    return json({ success: true });
  }

  // ── Prompts ───────────────────────────────────────────────────────

  getPrompts() {
    const rows = this.sql.exec('SELECT * FROM prompt_templates ORDER BY station').toArray();
    return json(rows);
  }

  updatePrompt(id, data) {
    this.sql.exec(
      `UPDATE prompt_templates SET
        system_block = ?,
        context_block = ?,
        logic_block = ?,
        constraints_block = ?,
        output_schema = ?,
        updated_at = datetime('now')
       WHERE id = ?`,
      data.system_block, data.context_block, data.logic_block,
      data.constraints_block, data.output_schema, id
    );
    return json({ success: true });
  }

  resetPrompts() {
    this.sql.exec('DELETE FROM prompt_templates');
    for (const p of DEFAULT_PROMPTS) {
      this.sql.exec(
        `INSERT INTO prompt_templates
         (id, station, label, system_block, context_block, logic_block, constraints_block, output_schema)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        p.id, p.station, p.label, p.system_block,
        p.context_block, p.logic_block, p.constraints_block, p.output_schema
      );
    }
    return json({ success: true });
  }

  // ── Files ─────────────────────────────────────────────────────────

  getFiles() {
    const rows = this.sql.exec('SELECT * FROM gemini_files ORDER BY uploaded_at DESC').toArray();
    return json(rows);
  }

  async uploadFile(formData) {
    const file = formData.get('file');
    if (!file) return json({ error: 'No file provided' }, 400);

    const buffer = await file.arrayBuffer();
    const mimeType = file.type || 'application/octet-stream';

    const geminiFile = await uploadToGeminiFileAPI(
      this.env.GEMINI_API_KEY,
      buffer,
      mimeType,
      file.name
    );

    const id = uuid();
    this.sql.exec(
      `INSERT INTO gemini_files (id, file_name, file_uri, mime_type, expires_at)
       VALUES (?, ?, ?, ?, ?)`,
      id, file.name, geminiFile.uri, mimeType, geminiFile.expirationTime || null
    );

    return json({ id, file_name: file.name, file_uri: geminiFile.uri });
  }

  async deleteFile(id) {
    const row = this.sql.exec('SELECT * FROM gemini_files WHERE id = ?', id).one();
    if (!row) return json({ error: 'File not found' }, 404);

    try {
      // Extract file name from URI for deletion
      const fileName = row.file_uri.split('/files/')[1];
      if (fileName) {
        await deleteGeminiFile(this.env.GEMINI_API_KEY, `files/${fileName}`);
      }
    } catch (e) {
      console.warn('Could not delete from Gemini File API:', e.message);
    }

    this.sql.exec('DELETE FROM gemini_files WHERE id = ?', id);
    return json({ success: true });
  }

  // ── Pipeline Sessions ─────────────────────────────────────────────

  getSessions() {
    const rows = this.sql.exec(
      'SELECT * FROM pipeline_sessions ORDER BY created_at DESC LIMIT 20'
    ).toArray();
    return json(rows);
  }

  createSession(data) {
    const id = uuid();
    this.sql.exec(
      'INSERT INTO pipeline_sessions (id, seed_keyword, niche, status) VALUES (?, ?, ?, ?)',
      id, data.seed_keyword || '', data.niche || '', 'active'
    );
    return json({ id, seed_keyword: data.seed_keyword, niche: data.niche, status: 'active' });
  }

  getSession(id) {
    const session = this.sql.exec(
      'SELECT * FROM pipeline_sessions WHERE id = ?', id
    ).one();
    if (!session) return json({ error: 'Session not found' }, 404);

    const stations = this.sql.exec(
      'SELECT * FROM pipeline_stations WHERE session_id = ? ORDER BY station',
      id
    ).toArray();

    const stationMap = {};
    for (const s of stations) {
      stationMap[s.station] = {
        ...s,
        input_data: s.input_data ? JSON.parse(s.input_data) : null,
        output_data: s.output_data ? JSON.parse(s.output_data) : null,
      };
    }

    return json({ ...session, stations: stationMap });
  }

  deleteSession(id) {
    this.sql.exec('DELETE FROM pipeline_stations WHERE session_id = ?', id);
    this.sql.exec('DELETE FROM pipeline_sessions WHERE id = ?', id);
    return json({ success: true });
  }

  // ── Station Execution ─────────────────────────────────────────────

  async executeStation(sessionId, stationNum) {
    const session = this.sql.exec(
      'SELECT * FROM pipeline_sessions WHERE id = ?', sessionId
    ).one();
    if (!session) return json({ error: 'Session not found' }, 404);

    const profile = this.sql.exec('SELECT * FROM vault_profile WHERE id = 1').one();
    if (!profile) return json({ error: 'Profile not configured' }, 400);

    const template = this.sql.exec(
      'SELECT * FROM prompt_templates WHERE station = ?', stationNum
    ).one();
    if (!template) return json({ error: `No prompt template for station ${stationNum}` }, 400);

    // Gather previous station outputs
    const prevStations = this.sql.exec(
      'SELECT * FROM pipeline_stations WHERE session_id = ? AND status = ? ORDER BY station',
      sessionId, 'complete'
    ).toArray();

    const sessionData = { ...session };
    for (const s of prevStations) {
      sessionData[`station_${s.station}_output`] = s.output_data
        ? JSON.parse(s.output_data)
        : null;
    }

    // Get file URIs for RAG
    const files = this.sql.exec('SELECT * FROM gemini_files').toArray();
    const fileUris = files.map(f => f.file_uri);
    const fileContext = files.length > 0
      ? `Uploaded files available: ${files.map(f => f.file_name).join(', ')}`
      : 'No files uploaded';

    // Build prompt
    const profileData = {
      ...profile,
      brand_tone: profile.brand_tone ? JSON.parse(profile.brand_tone) : []
    };
    const context = buildStationContext(profileData, stationNum, sessionData, fileContext);
    const { systemPrompt, userPrompt } = buildPrompt(template, context);

    // Create/update station record
    const stationId = uuid();
    this.sql.exec(
      `INSERT INTO pipeline_stations (id, session_id, station, input_data, status)
       VALUES (?, ?, ?, ?, ?)
       ON CONFLICT DO NOTHING`,
      stationId, sessionId, stationNum, JSON.stringify({ context }), 'running'
    );

    // Execute Gemini call
    let result;
    try {
      if (fileUris.length > 0) {
        result = await callGeminiWithFiles(
          this.env.GEMINI_API_KEY,
          this.env.GEMINI_MODEL || 'gemini-2.0-flash',
          systemPrompt,
          userPrompt,
          fileUris
        );
      } else {
        result = await callGemini(
          this.env.GEMINI_API_KEY,
          this.env.GEMINI_MODEL || 'gemini-2.0-flash',
          systemPrompt,
          userPrompt
        );
      }

      // Store result
      this.sql.exec(
        `UPDATE pipeline_stations SET output_data = ?, status = ?
         WHERE session_id = ? AND station = ?`,
        JSON.stringify(result), 'complete', sessionId, stationNum
      );

      // Update session status if station 4 complete
      if (stationNum === 4) {
        this.sql.exec(
          "UPDATE pipeline_sessions SET status = 'complete' WHERE id = ?",
          sessionId
        );
      }

      return json({ success: true, output: result, station: stationNum });

    } catch (e) {
      this.sql.exec(
        `UPDATE pipeline_stations SET status = ? WHERE session_id = ? AND station = ?`,
        'error', sessionId, stationNum
      );
      return json({ error: e.message }, 500);
    }
  }
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json' }
  });
}
