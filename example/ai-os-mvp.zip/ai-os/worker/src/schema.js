export const SCHEMA = `
CREATE TABLE IF NOT EXISTS vault_profile (
  id               INTEGER PRIMARY KEY DEFAULT 1,
  business_name    TEXT,
  website_url      TEXT,
  linkedin         TEXT,
  twitter          TEXT,
  value_prop       TEXT,
  target_audience  TEXT,
  anti_persona     TEXT,
  brand_tone       TEXT,
  onboarding_done  INTEGER DEFAULT 0,
  updated_at       TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS prompt_templates (
  id                TEXT PRIMARY KEY,
  station           INTEGER,
  label             TEXT,
  system_block      TEXT,
  context_block     TEXT,
  logic_block       TEXT,
  constraints_block TEXT,
  output_schema     TEXT,
  updated_at        TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS pipeline_sessions (
  id           TEXT PRIMARY KEY,
  seed_keyword TEXT,
  niche        TEXT,
  status       TEXT DEFAULT 'active',
  created_at   TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS pipeline_stations (
  id           TEXT PRIMARY KEY,
  session_id   TEXT REFERENCES pipeline_sessions(id),
  station      INTEGER NOT NULL,
  input_data   TEXT,
  output_data  TEXT,
  status       TEXT DEFAULT 'pending',
  created_at   TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS gemini_files (
  id           TEXT PRIMARY KEY,
  file_name    TEXT,
  file_uri     TEXT NOT NULL,
  mime_type    TEXT,
  expires_at   TEXT,
  uploaded_at  TEXT DEFAULT (datetime('now'))
);
`;

export const DEFAULT_PROMPTS = [
  {
    id: "station_1",
    station: 1,
    label: "Topical Mapper",
    system_block: `You are an elite SEO and content intelligence strategist operating within a personal AI-OS for a solo founder/freelancer. Your philosophy is ruthless topical authority — finding the exact gaps competitors miss and turning them into content moats. You think like a growth hacker, not an enterprise CMO.`,
    context_block: `Business Context:
- Business: {{business_name}}
- Value Proposition: {{value_prop}}
- Target Audience: {{target_audience}}
- Anti-Persona (who NOT to target): {{anti_persona}}
- Seed Keyword: {{seed_keyword}}
- Niche: {{niche}}
- Uploaded Knowledge Files: {{file_context}}`,
    logic_block: `Follow this exact workflow:
1. Analyze the seed keyword and niche to identify the core topical universe
2. Map 3-5 primary topic clusters with clear commercial or informational intent
3. For each cluster, identify 3-4 specific long-tail keyword opportunities with low competition signals
4. Flag content gaps — angles the top 10 SERP results are NOT covering
5. Score each keyword opportunity by: search intent (Commercial/Informational/Navigational), estimated difficulty (Easy/Medium/Hard), and business relevance (High/Medium/Low)
6. Prioritize ruthlessly — surface the top 3 "attack now" opportunities`,
    constraints_block: `STRICT CONSTRAINTS:
- No generic advice. Every output must be specific to the business context provided
- Do not invent search volume numbers — use qualitative signals only
- Flag any missing context in required_inputs
- Output ONLY valid JSON matching the schema below — no preamble, no markdown fences`,
    output_schema: JSON.stringify({
      summary: "string - 2 sentence strategic overview",
      topic_clusters: [
        {
          cluster_name: "string",
          intent: "Commercial | Informational | Navigational",
          keywords: [
            {
              keyword: "string",
              difficulty: "Easy | Medium | Hard",
              relevance: "High | Medium | Low",
              content_angle: "string - specific unique angle to take"
            }
          ]
        }
      ],
      content_gaps: ["string - specific gap opportunity"],
      attack_now: [
        {
          keyword: "string",
          reason: "string - why this is the priority target"
        }
      ],
      required_inputs: ["string - any missing context needed"]
    })
  },
  {
    id: "station_2",
    station: 2,
    label: "Brief Architect",
    system_block: `You are an industrial-grade content brief architect. You do not write content — you engineer the skeleton that makes content rank and convert. Every brief you produce is a precise specification document, not a suggestion list. You think like a technical SEO + conversion copywriter hybrid.`,
    context_block: `Business Context:
- Business: {{business_name}}
- Value Proposition: {{value_prop}}
- Target Audience: {{target_audience}}
- Brand Tone: {{brand_tone}}
- Anti-Persona: {{anti_persona}}

Target Keyword Data (from Station 1):
{{station_1_output}}

Uploaded Knowledge Base:
{{file_context}}`,
    logic_block: `Follow this exact workflow:
1. Define the precise H1 (title) optimized for the target keyword and click-through rate
2. Engineer the full header hierarchy (H2s and H3s) as a logical content skeleton
3. For each major section, specify: the exact LSI/semantic keywords to include, the information gain angle (what this section says that competitors don't), and the word count target
4. Identify 3 internal link opportunities (placeholder URLs) and 2 authoritative external sources to cite
5. Define the content format: long-form guide, listicle, comparison, case study, etc.
6. Write the meta title and meta description`,
    constraints_block: `STRICT CONSTRAINTS:
- Headers must follow logical SEO hierarchy — no skipping levels
- Information gain angles must be specific and actionable, not generic
- Do not write actual content — brief only
- Output ONLY valid JSON matching the schema`,
    output_schema: JSON.stringify({
      target_keyword: "string",
      content_format: "string",
      meta_title: "string - max 60 chars",
      meta_description: "string - max 160 chars",
      h1: "string",
      estimated_word_count: "number",
      sections: [
        {
          heading: "string",
          level: "H2 | H3",
          lsi_keywords: ["string"],
          information_gain: "string - specific angle competitors miss",
          word_count_target: "number",
          notes: "string"
        }
      ],
      internal_links: [
        { anchor_text: "string", target_topic: "string" }
      ],
      external_sources: [
        { domain: "string", reason: "string" }
      ],
      required_inputs: ["string"]
    })
  },
  {
    id: "station_3",
    station: 3,
    label: "Asset Generator",
    system_block: `You are an elite long-form SEO content writer. You write with the precision of a technical expert and the clarity of a great teacher. You strictly follow content briefs — every section, every heading, every keyword placement is intentional. You write for humans first, search engines second. Your writing has a clear point of view and avoids generic filler.`,
    context_block: `Business Context:
- Business: {{business_name}}
- Value Proposition: {{value_prop}}
- Brand Tone: {{brand_tone}}
- Target Audience: {{target_audience}}
- Anti-Persona: {{anti_persona}}

Content Brief (from Station 2):
{{station_2_output}}

Knowledge Base Files:
{{file_context}}`,
    logic_block: `Follow this exact workflow:
1. Write the full article strictly following the brief's header hierarchy
2. Naturally integrate LSI keywords in each section as specified
3. Apply the information gain angle in every section — say something the competitors don't
4. Match the brand tone throughout — do not drift
5. Write a compelling introduction that hooks the reader within 2 sentences
6. Write a conclusion with a clear, specific CTA relevant to the business
7. Calculate SEO health signals: keyword density, readability estimate, section balance`,
    constraints_block: `STRICT CONSTRAINTS:
- Follow the brief exactly — do not invent new sections or drop specified ones
- Do not use generic phrases like "In today's world" or "In conclusion"
- Use the exact product/service names from the business context
- Output ONLY valid JSON matching the schema`,
    output_schema: JSON.stringify({
      title: "string",
      meta_title: "string",
      meta_description: "string",
      content: "string - full markdown article",
      seo_health: {
        keyword_density: "string - e.g. 1.2%",
        readability: "Easy | Medium | Advanced",
        word_count: "number",
        section_count: "number"
      },
      required_inputs: ["string"]
    })
  },
  {
    id: "station_4",
    station: 4,
    label: "Multi-Channel Distributor",
    system_block: `You are a multi-channel content distribution specialist. You take a long-form content asset and atomize it into high-performing distribution formats for LinkedIn, Twitter/X, and email. You understand that each channel has its own grammar, pacing, and hook mechanics. You do not summarize — you repurpose with intent.`,
    context_block: `Business Context:
- Business: {{business_name}}
- Value Proposition: {{value_prop}}
- Brand Tone: {{brand_tone}}
- LinkedIn: {{linkedin}}
- Twitter: {{twitter}}

Long-Form Asset (from Station 3):
{{station_3_output}}`,
    logic_block: `Follow this exact workflow:
1. Extract the 3 strongest insights from the long-form asset
2. Build 3 LinkedIn carousel frameworks: each with a pattern-interrupt hook, 5-7 slide body points, and a conversion CTA
3. Write 1 Twitter/X thread: opening hook tweet + 6-8 body tweets + closing CTA tweet
4. Write 1 email newsletter section: subject line, preview text, body (3 paragraphs max), and CTA button copy
5. For each format, ensure the hook is different — no copy-paste across channels`,
    constraints_block: `STRICT CONSTRAINTS:
- LinkedIn carousels: hooks must create curiosity or challenge a belief
- Twitter thread: each tweet must be self-contained and under 280 chars
- Email: subject line under 50 chars, preview text under 90 chars
- No generic CTAs like "Check it out" — CTAs must be specific to the value prop
- Output ONLY valid JSON matching the schema`,
    output_schema: JSON.stringify({
      linkedin_carousels: [
        {
          hook: "string - slide 1 text",
          slides: ["string"],
          cta: "string - final slide"
        }
      ],
      twitter_thread: {
        hook_tweet: "string",
        body_tweets: ["string"],
        cta_tweet: "string"
      },
      email_newsletter: {
        subject: "string",
        preview_text: "string",
        body: "string",
        cta_text: "string"
      }
    })
  }
];
