/**
 * Prompt Engine
 * Interpolates prompt template blocks with runtime context data
 */

export function buildPrompt(template, context) {
  const interpolate = (text) => {
    if (!text) return '';
    return text.replace(/\{\{(\w+)\}\}/g, (match, key) => {
      const value = context[key];
      if (value === undefined || value === null || value === '') {
        return `[${key}: not provided]`;
      }
      if (typeof value === 'object') {
        return JSON.stringify(value, null, 2);
      }
      return String(value);
    });
  };

  const systemPrompt = interpolate(template.system_block);
  const contextBlock = interpolate(template.context_block);
  const logicBlock = interpolate(template.logic_block);
  const constraintsBlock = interpolate(template.constraints_block);
  const outputSchema = template.output_schema;

  const userPrompt = `
=== OPERATIONAL CONTEXT ===
${contextBlock}

=== EXECUTION WORKFLOW ===
${logicBlock}

=== OUTPUT CONSTRAINTS ===
${constraintsBlock}

=== REQUIRED OUTPUT SCHEMA ===
You must respond ONLY with valid JSON matching this exact structure:
${outputSchema}
`.trim();

  return { systemPrompt, userPrompt };
}

export function buildStationContext(profile, stationNumber, sessionData, fileContext) {
  const base = {
    business_name: profile.business_name || '',
    website_url: profile.website_url || '',
    linkedin: profile.linkedin || '',
    twitter: profile.twitter || '',
    value_prop: profile.value_prop || '',
    target_audience: profile.target_audience || '',
    anti_persona: profile.anti_persona || '',
    brand_tone: profile.brand_tone || '',
    file_context: fileContext || 'No files uploaded',
    seed_keyword: sessionData.seed_keyword || '',
    niche: sessionData.niche || '',
  };

  // Inject previous station outputs as context for downstream stations
  if (stationNumber >= 2 && sessionData.station_1_output) {
    base.station_1_output = JSON.stringify(sessionData.station_1_output, null, 2);
  }
  if (stationNumber >= 3 && sessionData.station_2_output) {
    base.station_2_output = JSON.stringify(sessionData.station_2_output, null, 2);
  }
  if (stationNumber >= 4 && sessionData.station_3_output) {
    base.station_3_output = JSON.stringify(sessionData.station_3_output, null, 2);
  }

  return base;
}
