const GEMINI_BASE = 'https://generativelanguage.googleapis.com/v1beta';

/**
 * Call Gemini generateContent with system + user prompt
 * Returns parsed JSON from the model response
 */
export async function callGemini(apiKey, model, systemPrompt, userPrompt) {
  const url = `${GEMINI_BASE}/models/${model}:generateContent?key=${apiKey}`;

  const body = {
    system_instruction: {
      parts: [{ text: systemPrompt }]
    },
    contents: [
      {
        role: 'user',
        parts: [{ text: userPrompt }]
      }
    ],
    generationConfig: {
      responseMimeType: 'application/json',
      temperature: 0.7,
      maxOutputTokens: 8192,
    }
  };

  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });

  if (!response.ok) {
    const err = await response.text();
    throw new Error(`Gemini API error ${response.status}: ${err}`);
  }

  const data = await response.json();
  const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;

  if (!text) throw new Error('Empty response from Gemini');

  try {
    // Strip any accidental markdown fences
    const clean = text.replace(/```json\n?|\n?```/g, '').trim();
    return JSON.parse(clean);
  } catch (e) {
    throw new Error(`Failed to parse Gemini JSON response: ${e.message}\nRaw: ${text.slice(0, 500)}`);
  }
}

/**
 * Call Gemini with file URIs for RAG
 */
export async function callGeminiWithFiles(apiKey, model, systemPrompt, userPrompt, fileUris) {
  const url = `${GEMINI_BASE}/models/${model}:generateContent?key=${apiKey}`;

  const fileParts = fileUris.map(uri => ({
    file_data: { mime_type: 'application/pdf', file_uri: uri }
  }));

  const body = {
    system_instruction: {
      parts: [{ text: systemPrompt }]
    },
    contents: [
      {
        role: 'user',
        parts: [
          ...fileParts,
          { text: userPrompt }
        ]
      }
    ],
    generationConfig: {
      responseMimeType: 'application/json',
      temperature: 0.7,
      maxOutputTokens: 8192,
    }
  };

  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });

  if (!response.ok) {
    const err = await response.text();
    throw new Error(`Gemini API error ${response.status}: ${err}`);
  }

  const data = await response.json();
  const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!text) throw new Error('Empty response from Gemini');

  try {
    const clean = text.replace(/```json\n?|\n?```/g, '').trim();
    return JSON.parse(clean);
  } catch (e) {
    throw new Error(`Failed to parse Gemini JSON: ${e.message}`);
  }
}

/**
 * Upload a file to Gemini File API
 */
export async function uploadToGeminiFileAPI(apiKey, fileBuffer, mimeType, displayName) {
  // Step 1: Initiate resumable upload
  const initUrl = `https://generativelanguage.googleapis.com/upload/v1beta/files?key=${apiKey}`;

  const initResponse = await fetch(initUrl, {
    method: 'POST',
    headers: {
      'X-Goog-Upload-Protocol': 'resumable',
      'X-Goog-Upload-Command': 'start',
      'X-Goog-Upload-Header-Content-Length': fileBuffer.byteLength,
      'X-Goog-Upload-Header-Content-Type': mimeType,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ file: { display_name: displayName } })
  });

  if (!initResponse.ok) {
    throw new Error(`File API init failed: ${await initResponse.text()}`);
  }

  const uploadUrl = initResponse.headers.get('x-goog-upload-url');
  if (!uploadUrl) throw new Error('No upload URL returned from File API');

  // Step 2: Upload the actual bytes
  const uploadResponse = await fetch(uploadUrl, {
    method: 'POST',
    headers: {
      'Content-Length': fileBuffer.byteLength,
      'X-Goog-Upload-Offset': '0',
      'X-Goog-Upload-Command': 'upload, finalize',
    },
    body: fileBuffer
  });

  if (!uploadResponse.ok) {
    throw new Error(`File upload failed: ${await uploadResponse.text()}`);
  }

  const fileData = await uploadResponse.json();
  return fileData.file; // { name, uri, mimeType, expirationTime, ... }
}

/**
 * List files in Gemini File API
 */
export async function listGeminiFiles(apiKey) {
  const url = `${GEMINI_BASE}/files?key=${apiKey}`;
  const response = await fetch(url);
  if (!response.ok) throw new Error(`List files failed: ${await response.text()}`);
  const data = await response.json();
  return data.files || [];
}

/**
 * Delete a file from Gemini File API
 */
export async function deleteGeminiFile(apiKey, fileName) {
  const url = `${GEMINI_BASE}/${fileName}?key=${apiKey}`;
  const response = await fetch(url, { method: 'DELETE' });
  if (!response.ok) throw new Error(`Delete file failed: ${await response.text()}`);
  return true;
}
