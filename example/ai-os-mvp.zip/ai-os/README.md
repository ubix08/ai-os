# AI-OS — Personal Content Marketing Engine

A personal AI Operating System for content marketing, built on:
- **React + Vite** (frontend, deployed to Cloudflare Pages)
- **Cloudflare Workers** (API gateway + auth)
- **Cloudflare Durable Objects with SQLite** (persistent state — one instance, forever)
- **Gemini 2.0 Flash** (AI pipeline agents)
- **Cloudflare Access** (Google OAuth login gate)

---

## Architecture

```
Cloudflare Pages (React SPA)
        ↓ fetch() + CF Access cookie
Cloudflare Worker (API gateway, auth validation)
        ↓ DO stub → idFromName("MASTER")
UserVault Durable Object (single instance)
    └── SQLite DB
          ├── vault_profile      (your business context)
          ├── prompt_templates   (editable agent prompts)
          ├── pipeline_sessions  (every content run)
          ├── pipeline_stations  (per-station outputs)
          └── gemini_files       (uploaded knowledge docs)
        ↓ HTTPS
Gemini API (gemini-2.0-flash + File API)
```

---

## The 4-Station Pipeline

| Station | Role | Output |
|---------|------|--------|
| 1 · Topical Mapper | Market intelligence, keyword clustering | Topic clusters, attack targets, content gaps |
| 2 · Brief Architect | Content blueprint engineering | Header hierarchy, LSI keywords, information gain angles |
| 3 · Asset Generator | Long-form SEO content production | Full article in markdown with SEO health metrics |
| 4 · Distributor | Multi-channel repurposing | LinkedIn carousels, X thread, email newsletter |

---

## Setup & Deployment

### Prerequisites
- [Cloudflare account](https://dash.cloudflare.com) (free tier)
- [Wrangler CLI](https://developers.cloudflare.com/workers/wrangler/install-and-update/): `npm install -g wrangler`
- [Node.js](https://nodejs.org) 18+
- Gemini API key from [Google AI Studio](https://aistudio.google.com)

---

### Step 1 — Deploy the Worker

```bash
cd worker
npm install

# Login to Cloudflare
wrangler login

# Set your secrets (never put these in wrangler.toml)
wrangler secret put GEMINI_API_KEY
# → paste your Gemini API key when prompted

# Deploy
wrangler deploy
```

Note the Worker URL output: `https://ai-os-worker.YOUR_SUBDOMAIN.workers.dev`

---

### Step 2 — Set up Cloudflare Access (Login Gate)

1. Go to [Cloudflare Zero Trust](https://one.dash.cloudflare.com) → Access → Applications
2. Click **Add an application** → **Self-hosted**
3. Name: `AI-OS`, Session Duration: `24 hours`
4. Application domain: your Pages URL (after Step 3)
5. Under **Policies**: Add policy → Include → Emails → add YOUR email only
6. After saving, go to the app's **Overview** and copy:
   - **Audience (AUD) tag** → `wrangler secret put CF_ACCESS_AUD`
   - **Team domain** → `wrangler secret put CF_ACCESS_TEAM_DOMAIN`

```bash
wrangler secret put CF_ACCESS_AUD
wrangler secret put CF_ACCESS_TEAM_DOMAIN
```

---

### Step 3 — Deploy the Frontend to Cloudflare Pages

```bash
cd frontend
npm install

# Copy and fill env
cp .env.example .env.local
# Set VITE_WORKER_URL to your Worker URL from Step 1

# Build
npm run build

# Deploy to Pages
wrangler pages deploy dist --project-name ai-os
```

Or connect your GitHub repo to Cloudflare Pages for automatic deploys:
- Build command: `cd frontend && npm run build`
- Build output directory: `frontend/dist`
- Root directory: `/`

---

### Step 4 — First Run

1. Open your Pages URL
2. Cloudflare Access will prompt Google login (only your email works)
3. Complete the 5-step onboarding wizard
4. Create your first pipeline run from the sidebar
5. Run stations 1→4 in sequence

---

## Local Development

```bash
# Terminal 1 — Worker (with DO support)
cd worker
npm install
wrangler dev

# Terminal 2 — Frontend
cd frontend
npm install
cp .env.example .env.local  # VITE_WORKER_URL=http://localhost:8787/api
npm run dev
```

> **Note:** In local dev, `CF_ACCESS_AUD` is not set so auth is bypassed automatically.
> Never deploy with this bypass active.

---

## Editing Prompts

Click **Prompt Editor** (top right) in the dashboard to edit any prompt block for any station.
Changes are stored in your personal Durable Object SQLite database.

To reset all prompts to defaults: Prompt Editor → Reset All.

---

## File Structure

```
ai-os/
├── frontend/               # React Vite SPA
│   ├── src/
│   │   ├── context/        # VaultContext (global state)
│   │   ├── components/
│   │   │   ├── onboarding/ # 5-step wizard + file upload
│   │   │   ├── pipeline/   # 4 station views
│   │   │   └── shared/     # Sidebar, TopBar, PromptEditor, etc.
│   │   └── utils/api.js    # Worker API client
│   └── package.json
└── worker/                 # Cloudflare Worker
    ├── src/
    │   ├── index.js         # Entry point + CF Access auth
    │   ├── UserVault.js     # Durable Object (all state + AI calls)
    │   ├── schema.js        # SQLite schema + default prompts
    │   ├── promptEngine.js  # Template interpolation
    │   └── geminiProxy.js   # Gemini API + File API calls
    └── wrangler.toml
```

---

## Customization

### Adding a new station
1. Add a new row to `DEFAULT_PROMPTS` in `worker/src/schema.js`
2. Create a new `StationN_Name.jsx` component
3. Add it to `PipelineShell.jsx`
4. Add it to the `TopBar.jsx` station list

### Changing the AI model
Update `GEMINI_MODEL` in `wrangler.toml` or via `wrangler secret put GEMINI_MODEL`.

---

## Cloudflare Free Tier Limits

| Resource | Free Limit | This App's Usage |
|----------|-----------|-----------------|
| Workers requests | 100k/day | ~4 requests per pipeline run |
| Durable Objects requests | 1M/month | ~10 per pipeline run |
| DO SQLite storage | 5GB | Negligible |
| Pages deploys | Unlimited | — |

Well within free tier for personal use.
