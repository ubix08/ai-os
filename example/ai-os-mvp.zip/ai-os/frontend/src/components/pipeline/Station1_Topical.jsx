import { useState } from 'react';
import { useVault } from '../../context/VaultContext';
import { Map, Zap, Loader2, AlertCircle, ChevronDown, ChevronRight, ArrowRight } from 'lucide-react';

const INTENT_COLORS = {
  Commercial: 'bg-signal-orange/15 text-signal-orange border-signal-orange/20',
  Informational: 'bg-signal-blue/15 text-signal-blue border-signal-blue/20',
  Navigational: 'bg-signal-purple/15 text-signal-purple border-signal-purple/20',
};
const DIFF_COLORS = {
  Easy: 'bg-acid/15 text-acid border-acid/20',
  Medium: 'bg-signal-orange/15 text-signal-orange border-signal-orange/20',
  Hard: 'bg-signal-red/15 text-signal-red border-signal-red/20',
};
const REL_COLORS = {
  High: 'text-acid', Medium: 'text-signal-orange', Low: 'text-gray-500'
};

export default function Station1Topical() {
  const { activeSession, executeStation, stationLoading, stationError, setCurrentStation } = useVault();
  const [expanded, setExpanded] = useState({});

  const stationData = activeSession?.stations?.[1];
  const output = stationData?.output_data;
  const isComplete = stationData?.status === 'complete';
  const isRunning = stationLoading;

  const toggle = (i) => setExpanded(p => ({ ...p, [i]: !p[i] }));

  if (!activeSession) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center space-y-3">
          <div className="w-14 h-14 bg-signal-blue/10 rounded-2xl flex items-center justify-center mx-auto">
            <Map size={24} className="text-signal-blue" />
          </div>
          <p className="font-display font-semibold text-white">Topical Mapper</p>
          <p className="text-gray-500 text-sm max-w-xs">Start a new pipeline run from the sidebar to begin mapping your content territory.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Station header */}
      <div className="px-6 py-5 border-b border-ink-700 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-signal-blue/10 rounded-xl flex items-center justify-center">
            <Map size={18} className="text-signal-blue" />
          </div>
          <div>
            <p className="font-display font-semibold text-white">Station 1 · Topical Mapper</p>
            <p className="text-gray-500 text-xs font-mono">
              Seed: <span className="text-signal-blue">{activeSession.seed_keyword}</span>
              {activeSession.niche && <> · Niche: <span className="text-gray-400">{activeSession.niche}</span></>}
            </p>
          </div>
        </div>
        {!isComplete && !isRunning && (
          <button onClick={() => executeStation(1)} className="btn-primary">
            <Zap size={15} /> Run Topical Analysis
          </button>
        )}
        {isComplete && (
          <button onClick={() => setCurrentStation(2)} className="btn-primary">
            Build Brief <ArrowRight size={15} />
          </button>
        )}
      </div>

      {/* Content area */}
      <div className="flex-1 overflow-y-auto p-6">
        {isRunning && !isComplete && (
          <div className="flex flex-col items-center justify-center h-64 gap-4">
            <div className="relative">
              <div className="w-16 h-16 bg-signal-blue/10 rounded-2xl flex items-center justify-center">
                <Map size={28} className="text-signal-blue" />
              </div>
              <Loader2 size={20} className="text-signal-blue animate-spin absolute -top-1 -right-1" />
            </div>
            <div className="text-center">
              <p className="font-display font-semibold text-white">Mapping topical territory…</p>
              <p className="text-gray-500 text-sm mt-1">Analyzing clusters and keyword opportunities</p>
            </div>
          </div>
        )}

        {stationError && (
          <div className="flex items-start gap-3 p-4 bg-signal-red/10 border border-signal-red/20 rounded-xl mb-6">
            <AlertCircle size={16} className="text-signal-red flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-signal-red text-sm font-medium">Execution Error</p>
              <p className="text-signal-red/70 text-xs mt-1 font-mono">{stationError}</p>
            </div>
          </div>
        )}

        {isComplete && output && (
          <div className="space-y-6 animate-fade-in">
            {/* Summary */}
            <div className="card">
              <p className="label mb-3">Strategic Overview</p>
              <p className="text-gray-300 text-sm leading-relaxed">{output.summary}</p>
            </div>

            {/* Attack Now */}
            {output.attack_now?.length > 0 && (
              <div>
                <p className="label mb-3">⚡ Attack Now — Priority Targets</p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {output.attack_now.map((item, i) => (
                    <div key={i} className="card-raised border-acid/20 hover:border-acid/40 transition-all">
                      <p className="font-mono text-sm text-acid font-medium">{item.keyword}</p>
                      <p className="text-gray-500 text-xs mt-2 leading-relaxed">{item.reason}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Topic Clusters */}
            {output.topic_clusters?.length > 0 && (
              <div>
                <p className="label mb-3">Topic Clusters</p>
                <div className="space-y-3">
                  {output.topic_clusters.map((cluster, i) => (
                    <div key={i} className="card overflow-hidden">
                      <button
                        className="w-full flex items-center justify-between text-left"
                        onClick={() => toggle(i)}>
                        <div className="flex items-center gap-3">
                          <span className={`badge border ${INTENT_COLORS[cluster.intent] || 'bg-ink-700 text-gray-400 border-ink-600'}`}>
                            {cluster.intent}
                          </span>
                          <p className="font-display font-semibold text-white text-sm">{cluster.cluster_name}</p>
                          <span className="text-gray-600 text-xs font-mono">{cluster.keywords?.length} keywords</span>
                        </div>
                        {expanded[i]
                          ? <ChevronDown size={16} className="text-gray-500" />
                          : <ChevronRight size={16} className="text-gray-500" />}
                      </button>

                      {expanded[i] && (
                        <div className="mt-4 pt-4 border-t border-ink-700 animate-fade-in">
                          <div className="space-y-2">
                            {cluster.keywords?.map((kw, j) => (
                              <div key={j}
                                className="flex items-start gap-3 p-3 bg-ink-800 rounded-lg hover:bg-ink-700/50 transition-all">
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-center gap-2 flex-wrap">
                                    <p className="font-mono text-sm text-white">{kw.keyword}</p>
                                    <span className={`badge border text-xs ${DIFF_COLORS[kw.difficulty] || 'bg-ink-700 text-gray-400 border-ink-600'}`}>
                                      {kw.difficulty}
                                    </span>
                                    <span className={`text-xs font-mono ${REL_COLORS[kw.relevance] || 'text-gray-400'}`}>
                                      {kw.relevance} relevance
                                    </span>
                                  </div>
                                  <p className="text-gray-500 text-xs mt-1.5 leading-relaxed">{kw.content_angle}</p>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Content Gaps */}
            {output.content_gaps?.length > 0 && (
              <div>
                <p className="label mb-3">Content Gaps Identified</p>
                <div className="space-y-2">
                  {output.content_gaps.map((gap, i) => (
                    <div key={i}
                      className="flex items-start gap-3 px-4 py-3 bg-signal-purple/5 border border-signal-purple/15 rounded-lg">
                      <span className="text-signal-purple mt-0.5 flex-shrink-0">◆</span>
                      <p className="text-gray-300 text-sm">{gap}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Required inputs */}
            {output.required_inputs?.length > 0 && (
              <div className="flex items-start gap-3 p-4 bg-signal-orange/10 border border-signal-orange/20 rounded-xl">
                <AlertCircle size={16} className="text-signal-orange flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-signal-orange text-sm font-medium mb-1">Missing Context</p>
                  <ul className="space-y-1">
                    {output.required_inputs.map((item, i) => (
                      <li key={i} className="text-signal-orange/70 text-xs font-mono">{item}</li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
          </div>
        )}

        {!isRunning && !isComplete && !stationError && (
          <div className="flex flex-col items-center justify-center h-48 gap-3 text-center">
            <Map size={32} className="text-ink-600" />
            <p className="text-gray-600 text-sm">
              Click "Run Topical Analysis" to map your content territory.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
