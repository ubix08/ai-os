import { useState } from 'react';
import { useVault } from '../../context/VaultContext';
import { Share2, Zap, Loader2, AlertCircle, Copy, CheckCircle, Linkedin, Twitter, Mail } from 'lucide-react';

function CopyButton({ text }) {
  const [copied, setCopied] = useState(false);
  const handle = async () => {
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  return (
    <button onClick={handle} className="btn-ghost text-xs gap-1">
      {copied ? <CheckCircle size={12} className="text-acid" /> : <Copy size={12} />}
      {copied ? 'Copied' : 'Copy'}
    </button>
  );
}

export default function Station4Distribution() {
  const { activeSession, executeStation, stationLoading, stationError } = useVault();
  const [activeCarousel, setActiveCarousel] = useState(0);

  const stationData = activeSession?.stations?.[4];
  const output = stationData?.output_data;
  const isComplete = stationData?.status === 'complete';
  const isRunning = stationLoading && !isComplete;
  const prevComplete = activeSession?.stations?.[3]?.status === 'complete';

  if (!activeSession) return null;

  const carousels = output?.linkedin_carousels || [];
  const thread = output?.twitter_thread;
  const email = output?.email_newsletter;

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <div className="px-6 py-5 border-b border-ink-700 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-signal-orange/10 rounded-xl flex items-center justify-center">
            <Share2 size={18} className="text-signal-orange" />
          </div>
          <div>
            <p className="font-display font-semibold text-white">Station 4 · Multi-Channel Distributor</p>
            <p className="text-gray-500 text-xs font-mono">LinkedIn · Twitter/X · Email</p>
          </div>
        </div>
        {!isComplete && !isRunning && prevComplete && (
          <button onClick={() => executeStation(4)} className="btn-primary">
            <Zap size={15} /> Generate Distribution Assets
          </button>
        )}
        {!prevComplete && (
          <p className="text-gray-600 text-xs font-mono">Complete Station 3 first</p>
        )}
        {isComplete && (
          <div className="flex items-center gap-2 px-3 py-1.5 bg-acid/10 border border-acid/20 rounded-lg">
            <CheckCircle size={14} className="text-acid" />
            <span className="text-acid text-xs font-mono font-semibold">Pipeline Complete</span>
          </div>
        )}
      </div>

      <div className="flex-1 overflow-y-auto p-6">
        {isRunning && (
          <div className="flex flex-col items-center justify-center h-64 gap-4">
            <div className="relative">
              <div className="w-16 h-16 bg-signal-orange/10 rounded-2xl flex items-center justify-center">
                <Share2 size={28} className="text-signal-orange" />
              </div>
              <Loader2 size={20} className="text-signal-orange animate-spin absolute -top-1 -right-1" />
            </div>
            <div className="text-center">
              <p className="font-display font-semibold text-white">Atomizing content for distribution…</p>
              <p className="text-gray-500 text-sm mt-1">Building LinkedIn carousels, X thread, and email</p>
            </div>
          </div>
        )}

        {stationError && (
          <div className="flex items-start gap-3 p-4 bg-signal-red/10 border border-signal-red/20 rounded-xl">
            <AlertCircle size={16} className="text-signal-red flex-shrink-0 mt-0.5" />
            <p className="text-signal-red text-sm font-mono">{stationError}</p>
          </div>
        )}

        {isComplete && output && (
          <div className="space-y-8 animate-fade-in">

            {/* LinkedIn Carousels */}
            {carousels.length > 0 && (
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-7 h-7 bg-[#0A66C2]/15 rounded-lg flex items-center justify-center">
                    <Linkedin size={14} className="text-[#0A66C2]" />
                  </div>
                  <p className="font-display font-semibold text-white">LinkedIn Carousels</p>
                  <p className="text-gray-600 text-xs font-mono">({carousels.length} frameworks)</p>
                </div>

                {/* Carousel selector */}
                <div className="flex gap-2 mb-4">
                  {carousels.map((_, i) => (
                    <button key={i} onClick={() => setActiveCarousel(i)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-mono transition-all
                        ${activeCarousel === i
                          ? 'bg-[#0A66C2]/20 text-[#0A66C2] border border-[#0A66C2]/30'
                          : 'bg-ink-800 text-gray-500 hover:text-gray-300'}`}>
                      Carousel {i + 1}
                    </button>
                  ))}
                </div>

                {carousels[activeCarousel] && (
                  <div className="space-y-3">
                    {/* Hook slide */}
                    <div className="card border-[#0A66C2]/20 bg-[#0A66C2]/5">
                      <div className="flex items-center justify-between mb-2">
                        <span className="badge bg-[#0A66C2]/15 text-[#0A66C2] border border-[#0A66C2]/20 text-xs font-mono">
                          Slide 1 · Hook
                        </span>
                        <CopyButton text={carousels[activeCarousel].hook} />
                      </div>
                      <p className="text-white text-sm font-semibold leading-relaxed">
                        {carousels[activeCarousel].hook}
                      </p>
                    </div>

                    {/* Body slides */}
                    <div className="space-y-2">
                      {carousels[activeCarousel].slides?.map((slide, i) => (
                        <div key={i} className="card">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-gray-600 text-xs font-mono">Slide {i + 2}</span>
                            <CopyButton text={slide} />
                          </div>
                          <p className="text-gray-300 text-sm leading-relaxed">{slide}</p>
                        </div>
                      ))}
                    </div>

                    {/* CTA slide */}
                    {carousels[activeCarousel].cta && (
                      <div className="card border-acid/20 bg-acid/5">
                        <div className="flex items-center justify-between mb-2">
                          <span className="badge bg-acid/15 text-acid border border-acid/20 text-xs font-mono">
                            Final Slide · CTA
                          </span>
                          <CopyButton text={carousels[activeCarousel].cta} />
                        </div>
                        <p className="text-acid text-sm font-semibold">{carousels[activeCarousel].cta}</p>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Twitter Thread */}
            {thread && (
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-7 h-7 bg-white/5 rounded-lg flex items-center justify-center">
                    <Twitter size={14} className="text-white" />
                  </div>
                  <p className="font-display font-semibold text-white">Twitter / X Thread</p>
                  <CopyButton text={[thread.hook_tweet, ...(thread.body_tweets || []), thread.cta_tweet].join('\n\n---\n\n')} />
                </div>
                <div className="space-y-2">
                  {[
                    { tweet: thread.hook_tweet, label: 'Hook', highlight: true },
                    ...(thread.body_tweets || []).map((t, i) => ({ tweet: t, label: `${i + 2}` })),
                    { tweet: thread.cta_tweet, label: 'CTA', highlight: true }
                  ].map((item, i) => (
                    <div key={i} className={`flex gap-3 p-3 rounded-xl border
                      ${item.highlight ? 'bg-white/5 border-white/10' : 'bg-ink-800 border-ink-600'}`}>
                      <span className="font-mono text-xs text-gray-600 w-6 flex-shrink-0 pt-0.5">{item.label}</span>
                      <div className="flex-1">
                        <p className="text-gray-300 text-sm leading-relaxed">{item.tweet}</p>
                        <p className="text-gray-600 text-xs font-mono mt-1">{item.tweet?.length}/280</p>
                      </div>
                      <CopyButton text={item.tweet} />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Email Newsletter */}
            {email && (
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-7 h-7 bg-signal-purple/10 rounded-lg flex items-center justify-center">
                    <Mail size={14} className="text-signal-purple" />
                  </div>
                  <p className="font-display font-semibold text-white">Email Newsletter</p>
                </div>
                <div className="space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <div className="card">
                      <div className="flex items-center justify-between mb-2">
                        <p className="label">Subject Line</p>
                        <CopyButton text={email.subject} />
                      </div>
                      <p className="text-white text-sm font-semibold">{email.subject}</p>
                      <p className="text-gray-600 text-xs font-mono mt-1">{email.subject?.length}/50 chars</p>
                    </div>
                    <div className="card">
                      <div className="flex items-center justify-between mb-2">
                        <p className="label">Preview Text</p>
                        <CopyButton text={email.preview_text} />
                      </div>
                      <p className="text-gray-300 text-sm">{email.preview_text}</p>
                      <p className="text-gray-600 text-xs font-mono mt-1">{email.preview_text?.length}/90 chars</p>
                    </div>
                  </div>
                  <div className="card">
                    <div className="flex items-center justify-between mb-3">
                      <p className="label">Body</p>
                      <CopyButton text={email.body} />
                    </div>
                    <p className="text-gray-300 text-sm leading-relaxed whitespace-pre-line">{email.body}</p>
                  </div>
                  {email.cta_text && (
                    <div className="card border-signal-purple/20 bg-signal-purple/5">
                      <p className="label mb-2">CTA Button Copy</p>
                      <div className="flex items-center justify-between">
                        <p className="text-signal-purple font-display font-semibold">{email.cta_text}</p>
                        <CopyButton text={email.cta_text} />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {!isRunning && !isComplete && !stationError && prevComplete && (
          <div className="flex flex-col items-center justify-center h-48 gap-3 text-center">
            <Share2 size={32} className="text-ink-600" />
            <p className="text-gray-600 text-sm">Ready to atomize your content into distribution assets.</p>
          </div>
        )}
      </div>
    </div>
  );
}
