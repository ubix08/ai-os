import { useVault } from '../../context/VaultContext';
import { FileText, Zap, Loader2, AlertCircle, ArrowRight, Link, ExternalLink } from 'lucide-react';

const LEVEL_COLORS = { H2: 'text-signal-purple', H3: 'text-signal-blue ml-4' };

export default function Station2Brief() {
  const { activeSession, executeStation, stationLoading, stationError, setCurrentStation } = useVault();

  const stationData = activeSession?.stations?.[2];
  const output = stationData?.output_data;
  const isComplete = stationData?.status === 'complete';
  const isRunning = stationLoading && !isComplete;
  const prevComplete = activeSession?.stations?.[1]?.status === 'complete';

  if (!activeSession) return null;

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <div className="px-6 py-5 border-b border-ink-700 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-signal-purple/10 rounded-xl flex items-center justify-center">
            <FileText size={18} className="text-signal-purple" />
          </div>
          <div>
            <p className="font-display font-semibold text-white">Station 2 · Brief Architect</p>
            <p className="text-gray-500 text-xs font-mono">Industrial-grade content brief generation</p>
          </div>
        </div>
        {!isComplete && !isRunning && prevComplete && (
          <button onClick={() => executeStation(2)} className="btn-primary">
            <Zap size={15} /> Generate Brief
          </button>
        )}
        {!prevComplete && (
          <p className="text-gray-600 text-xs font-mono">Complete Station 1 first</p>
        )}
        {isComplete && (
          <button onClick={() => setCurrentStation(3)} className="btn-primary">
            Generate Asset <ArrowRight size={15} />
          </button>
        )}
      </div>

      <div className="flex-1 overflow-y-auto p-6">
        {isRunning && (
          <div className="flex flex-col items-center justify-center h-64 gap-4">
            <div className="relative">
              <div className="w-16 h-16 bg-signal-purple/10 rounded-2xl flex items-center justify-center">
                <FileText size={28} className="text-signal-purple" />
              </div>
              <Loader2 size={20} className="text-signal-purple animate-spin absolute -top-1 -right-1" />
            </div>
            <div className="text-center">
              <p className="font-display font-semibold text-white">Architecting content brief…</p>
              <p className="text-gray-500 text-sm mt-1">Engineering header hierarchy and information gain angles</p>
            </div>
          </div>
        )}

        {stationError && (
          <div className="flex items-start gap-3 p-4 bg-signal-red/10 border border-signal-red/20 rounded-xl mb-6">
            <AlertCircle size={16} className="text-signal-red flex-shrink-0 mt-0.5" />
            <p className="text-signal-red text-sm font-mono">{stationError}</p>
          </div>
        )}

        {isComplete && output && (
          <div className="space-y-6 animate-fade-in">
            {/* Meta */}
            <div className="grid grid-cols-2 gap-4">
              <div className="card col-span-2">
                <div className="flex items-center gap-2 mb-3">
                  <span className="badge bg-signal-purple/15 text-signal-purple border border-signal-purple/20">
                    {output.content_format}
                  </span>
                  <span className="font-mono text-xs text-gray-600">~{output.estimated_word_count?.toLocaleString()} words</span>
                </div>
                <p className="font-display font-bold text-xl text-white">{output.h1}</p>
              </div>
              <div className="card">
                <p className="label mb-2">Meta Title</p>
                <p className="text-gray-300 text-sm font-mono">{output.meta_title}</p>
                <p className="text-gray-600 text-xs mt-1 font-mono">{output.meta_title?.length}/60 chars</p>
              </div>
              <div className="card">
                <p className="label mb-2">Meta Description</p>
                <p className="text-gray-300 text-sm">{output.meta_description}</p>
                <p className="text-gray-600 text-xs mt-1 font-mono">{output.meta_description?.length}/160 chars</p>
              </div>
            </div>

            {/* Sections */}
            {output.sections?.length > 0 && (
              <div>
                <p className="label mb-3">Content Architecture</p>
                <div className="space-y-3">
                  {output.sections.map((section, i) => (
                    <div key={i} className="card">
                      <div className="flex items-start gap-3">
                        <span className="font-mono text-xs text-gray-600 mt-1 flex-shrink-0 w-6">{section.level}</span>
                        <div className="flex-1">
                          <p className={`font-display font-semibold text-sm ${LEVEL_COLORS[section.level] || 'text-white'}`}>
                            {section.heading}
                          </p>
                          {section.information_gain && (
                            <p className="text-gray-500 text-xs mt-1.5 leading-relaxed">
                              <span className="text-acid">↳ Angle:</span> {section.information_gain}
                            </p>
                          )}
                          {section.lsi_keywords?.length > 0 && (
                            <div className="flex flex-wrap gap-1.5 mt-2">
                              {section.lsi_keywords.map((kw, j) => (
                                <span key={j} className="badge bg-ink-700 text-gray-400 text-xs font-mono">
                                  {kw}
                                </span>
                              ))}
                            </div>
                          )}
                          <div className="flex items-center gap-3 mt-2">
                            <span className="text-gray-600 text-xs font-mono">~{section.word_count_target} words</span>
                            {section.notes && (
                              <span className="text-gray-600 text-xs">{section.notes}</span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Links */}
            <div className="grid grid-cols-2 gap-4">
              {output.internal_links?.length > 0 && (
                <div className="card">
                  <p className="label mb-3">Internal Links</p>
                  <div className="space-y-2">
                    {output.internal_links.map((link, i) => (
                      <div key={i} className="flex items-center gap-2">
                        <Link size={12} className="text-signal-blue flex-shrink-0" />
                        <div>
                          <p className="text-white text-xs font-mono">{link.anchor_text}</p>
                          <p className="text-gray-600 text-xs">{link.target_topic}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              {output.external_sources?.length > 0 && (
                <div className="card">
                  <p className="label mb-3">External Sources</p>
                  <div className="space-y-2">
                    {output.external_sources.map((src, i) => (
                      <div key={i} className="flex items-center gap-2">
                        <ExternalLink size={12} className="text-signal-orange flex-shrink-0" />
                        <div>
                          <p className="text-white text-xs font-mono">{src.domain}</p>
                          <p className="text-gray-600 text-xs">{src.reason}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {!isRunning && !isComplete && !stationError && prevComplete && (
          <div className="flex flex-col items-center justify-center h-48 gap-3 text-center">
            <FileText size={32} className="text-ink-600" />
            <p className="text-gray-600 text-sm">Ready to build your content brief from Station 1 output.</p>
          </div>
        )}
      </div>
    </div>
  );
}
