import { useState } from 'react';
import { useVault } from '../../context/VaultContext';
import { PenSquare, Zap, Loader2, AlertCircle, ArrowRight, Copy, CheckCircle, Eye, Code } from 'lucide-react';

function renderMarkdown(md) {
  if (!md) return '';
  return md
    .replace(/^# (.+)$/gm, '<h1 class="text-2xl font-display font-bold text-white mt-6 mb-3">$1</h1>')
    .replace(/^## (.+)$/gm, '<h2 class="text-xl font-display font-semibold text-white mt-5 mb-2">$1</h2>')
    .replace(/^### (.+)$/gm, '<h3 class="text-base font-display font-semibold text-gray-200 mt-4 mb-2">$1</h3>')
    .replace(/\*\*(.+?)\*\*/g, '<strong class="text-white font-semibold">$1</strong>')
    .replace(/\*(.+?)\*/g, '<em class="text-gray-300 italic">$1</em>')
    .replace(/^- (.+)$/gm, '<li class="text-gray-300 text-sm leading-relaxed ml-4 list-disc">$1</li>')
    .replace(/^(\d+)\. (.+)$/gm, '<li class="text-gray-300 text-sm leading-relaxed ml-4 list-decimal">$2</li>')
    .replace(/\n\n/g, '</p><p class="text-gray-400 text-sm leading-relaxed mb-3">')
    .replace(/^(?!<[h|l])/gm, '')
}

export default function Station3Asset() {
  const { activeSession, executeStation, stationLoading, stationError, setCurrentStation } = useVault();
  const [view, setView] = useState('preview'); // 'preview' | 'raw'
  const [copied, setCopied] = useState(false);

  const stationData = activeSession?.stations?.[3];
  const output = stationData?.output_data;
  const isComplete = stationData?.status === 'complete';
  const isRunning = stationLoading && !isComplete;
  const prevComplete = activeSession?.stations?.[2]?.status === 'complete';

  const handleCopy = async () => {
    if (output?.content) {
      await navigator.clipboard.writeText(output.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  if (!activeSession) return null;

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <div className="px-6 py-5 border-b border-ink-700 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-acid/10 rounded-xl flex items-center justify-center">
            <PenSquare size={18} className="text-acid" />
          </div>
          <div>
            <p className="font-display font-semibold text-white">Station 3 · Asset Generator</p>
            <p className="text-gray-500 text-xs font-mono">Long-form SEO content production</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {isComplete && (
            <>
              {/* View toggle */}
              <div className="flex items-center gap-1 bg-ink-800 rounded-lg p-1">
                <button onClick={() => setView('preview')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs transition-all
                    ${view === 'preview' ? 'bg-surface-raised text-white' : 'text-gray-500 hover:text-gray-300'}`}>
                  <Eye size={12} /> Preview
                </button>
                <button onClick={() => setView('raw')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs transition-all
                    ${view === 'raw' ? 'bg-surface-raised text-white' : 'text-gray-500 hover:text-gray-300'}`}>
                  <Code size={12} /> Markdown
                </button>
              </div>
              <button onClick={handleCopy} className="btn-ghost text-xs gap-1.5">
                {copied ? <CheckCircle size={13} className="text-acid" /> : <Copy size={13} />}
                {copied ? 'Copied!' : 'Copy'}
              </button>
              <button onClick={() => setCurrentStation(4)} className="btn-primary">
                Distribute <ArrowRight size={15} />
              </button>
            </>
          )}
          {!isComplete && !isRunning && prevComplete && (
            <button onClick={() => executeStation(3)} className="btn-primary">
              <Zap size={15} /> Generate Asset
            </button>
          )}
          {!prevComplete && (
            <p className="text-gray-600 text-xs font-mono">Complete Station 2 first</p>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6">
        {isRunning && (
          <div className="flex flex-col items-center justify-center h-64 gap-4">
            <div className="relative">
              <div className="w-16 h-16 bg-acid/10 rounded-2xl flex items-center justify-center">
                <PenSquare size={28} className="text-acid" />
              </div>
              <Loader2 size={20} className="text-acid animate-spin absolute -top-1 -right-1" />
            </div>
            <div className="text-center">
              <p className="font-display font-semibold text-white">Writing content asset…</p>
              <p className="text-gray-500 text-sm mt-1">This may take 30-60 seconds for long-form content</p>
            </div>
          </div>
        )}

        {stationError && (
          <div className="flex items-start gap-3 p-4 bg-signal-red/10 border border-signal-red/20 rounded-xl">
            <AlertCircle size={16} className="text-signal-red flex-shrink-0 mt-0.5" />
            <p className="text-signal-red text-sm font-mono">{stationError}</p>
          </div>
        )}

        {isComplete && output && (
          <div className="space-y-4 animate-fade-in">
            {/* SEO Health */}
            {output.seo_health && (
              <div className="flex items-center gap-4 p-4 bg-ink-800 border border-ink-600 rounded-xl">
                <div className="flex items-center gap-4 flex-wrap">
                  <div>
                    <p className="label">Word Count</p>
                    <p className="font-display font-bold text-acid text-lg">
                      {output.seo_health.word_count?.toLocaleString()}
                    </p>
                  </div>
                  <div className="w-px h-8 bg-ink-600" />
                  <div>
                    <p className="label">Keyword Density</p>
                    <p className="font-mono text-white text-sm">{output.seo_health.keyword_density}</p>
                  </div>
                  <div className="w-px h-8 bg-ink-600" />
                  <div>
                    <p className="label">Readability</p>
                    <span className={`badge border font-mono text-xs
                      ${output.seo_health.readability === 'Easy' ? 'bg-acid/15 text-acid border-acid/20' :
                        output.seo_health.readability === 'Medium' ? 'bg-signal-orange/15 text-signal-orange border-signal-orange/20' :
                        'bg-signal-purple/15 text-signal-purple border-signal-purple/20'}`}>
                      {output.seo_health.readability}
                    </span>
                  </div>
                  <div className="w-px h-8 bg-ink-600" />
                  <div>
                    <p className="label">Sections</p>
                    <p className="font-mono text-white text-sm">{output.seo_health.section_count}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Content */}
            <div className="card min-h-96">
              {view === 'preview' ? (
                <div
                  className="prose-sm text-gray-300 leading-relaxed"
                  dangerouslySetInnerHTML={{ __html: renderMarkdown(output.content) }}
                />
              ) : (
                <pre className="font-mono text-xs text-gray-400 whitespace-pre-wrap leading-relaxed overflow-x-auto">
                  {output.content}
                </pre>
              )}
            </div>
          </div>
        )}

        {!isRunning && !isComplete && !stationError && prevComplete && (
          <div className="flex flex-col items-center justify-center h-48 gap-3 text-center">
            <PenSquare size={32} className="text-ink-600" />
            <p className="text-gray-600 text-sm">Ready to generate long-form content from your approved brief.</p>
          </div>
        )}
      </div>
    </div>
  );
}
