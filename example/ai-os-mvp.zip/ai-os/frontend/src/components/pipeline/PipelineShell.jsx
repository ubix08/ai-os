import { useVault } from '../../context/VaultContext';
import Station1Topical from './Station1_Topical';
import Station2Brief from './Station2_Brief';
import Station3Asset from './Station3_Asset';
import Station4Distribution from './Station4_Distribution';
import { Zap } from 'lucide-react';

export default function PipelineShell() {
  const { activeSession, currentStation } = useVault();

  if (!activeSession) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center space-y-4 max-w-sm">
          <div className="w-20 h-20 bg-acid/10 rounded-3xl flex items-center justify-center mx-auto glow-acid">
            <Zap size={36} className="text-acid" />
          </div>
          <div>
            <p className="font-display font-bold text-xl text-white">Content Marketing OS</p>
            <p className="text-gray-500 text-sm mt-2 leading-relaxed">
              Your AI-powered content production pipeline. Start a new run from the sidebar to begin mapping, briefing, writing, and distributing content.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-2 text-left">
            {[
              { label: 'Station 1', desc: 'Topical mapping & keyword research', color: 'text-signal-blue' },
              { label: 'Station 2', desc: 'Industrial-grade content brief', color: 'text-signal-purple' },
              { label: 'Station 3', desc: 'Long-form SEO asset generation', color: 'text-acid' },
              { label: 'Station 4', desc: 'Multi-channel distribution assets', color: 'text-signal-orange' },
            ].map(s => (
              <div key={s.label} className="card p-3">
                <p className={`font-mono text-xs font-semibold ${s.color}`}>{s.label}</p>
                <p className="text-gray-600 text-xs mt-0.5 leading-tight">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      {currentStation === 1 && <Station1Topical />}
      {currentStation === 2 && <Station2Brief />}
      {currentStation === 3 && <Station3Asset />}
      {currentStation === 4 && <Station4Distribution />}
    </>
  );
}
