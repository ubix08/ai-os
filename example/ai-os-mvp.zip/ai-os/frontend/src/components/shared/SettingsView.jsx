import { useState } from 'react';
import { useVault } from '../../context/VaultContext';
import { Settings, Save, Loader2, CheckCircle } from 'lucide-react';
import StepKnowledgeDrive from '../onboarding/StepKnowledgeDrive';

const TONES = [
  { id: 'conversational', label: 'Conversational' },
  { id: 'aggressive', label: 'Aggressive' },
  { id: 'technical', label: 'Technical' },
  { id: 'bold', label: 'Bold' },
  { id: 'data_driven', label: 'Data-Driven' },
];

export default function SettingsView() {
  const { profile, saveProfile } = useVault();
  const [form, setForm] = useState({ ...profile });
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const set = (k, v) => setForm(p => ({ ...p, [k]: v }));
  const toggleTone = (id) => {
    const tones = form.brand_tone || [];
    set('brand_tone', tones.includes(id) ? tones.filter(t => t !== id) : [...tones, id]);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await saveProfile(form);
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto p-6 max-w-2xl mx-auto w-full">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <Settings size={18} className="text-gray-500" />
          <p className="font-display font-semibold text-white">Settings & Profile</p>
        </div>
        <button onClick={handleSave} disabled={saving} className="btn-primary text-sm">
          {saving ? <Loader2 size={14} className="animate-spin" /> :
            saved ? <CheckCircle size={14} /> : <Save size={14} />}
          {saved ? 'Saved!' : 'Save Profile'}
        </button>
      </div>

      <div className="space-y-6">
        {/* Basics */}
        <div className="card space-y-4">
          <p className="section-title">Business Profile</p>
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <label className="label">Business Name</label>
              <input className="input" value={form.business_name || ''} onChange={e => set('business_name', e.target.value)} />
            </div>
            <div className="col-span-2">
              <label className="label">Website URL</label>
              <input className="input" value={form.website_url || ''} onChange={e => set('website_url', e.target.value)} />
            </div>
            <div>
              <label className="label">LinkedIn</label>
              <input className="input" value={form.linkedin || ''} onChange={e => set('linkedin', e.target.value)} />
            </div>
            <div>
              <label className="label">Twitter / X</label>
              <input className="input" value={form.twitter || ''} onChange={e => set('twitter', e.target.value)} />
            </div>
          </div>
        </div>

        {/* Value Prop */}
        <div className="card space-y-4">
          <p className="section-title">Market Positioning</p>
          <div>
            <label className="label">Value Proposition</label>
            <textarea className="textarea" rows={4} value={form.value_prop || ''} onChange={e => set('value_prop', e.target.value)} />
          </div>
          <div>
            <label className="label">Target Audience</label>
            <textarea className="textarea" rows={3} value={form.target_audience || ''} onChange={e => set('target_audience', e.target.value)} />
          </div>
          <div>
            <label className="label">Anti-Persona (who NOT to target)</label>
            <textarea className="textarea" rows={3} value={form.anti_persona || ''} onChange={e => set('anti_persona', e.target.value)} />
          </div>
        </div>

        {/* Brand Tone */}
        <div className="card space-y-4">
          <p className="section-title">Brand Voice</p>
          <div className="flex flex-wrap gap-2">
            {TONES.map(t => (
              <button key={t.id} onClick={() => toggleTone(t.id)}
                className={`px-4 py-2 rounded-lg text-sm font-mono border transition-all
                  ${(form.brand_tone || []).includes(t.id)
                    ? 'bg-acid/10 border-acid/40 text-acid'
                    : 'bg-ink-800 border-ink-600 text-gray-400 hover:border-ink-500'}`}>
                {(form.brand_tone || []).includes(t.id) ? '✓ ' : ''}{t.label}
              </button>
            ))}
          </div>
        </div>

        {/* Knowledge Drive */}
        <div className="card space-y-4">
          <p className="section-title">Knowledge Drive</p>
          <p className="text-gray-500 text-sm">Upload documents to ground the AI agents in your specific business context.</p>
          <StepKnowledgeDrive />
        </div>
      </div>
    </div>
  );
}
