import { useVault } from '../../context/VaultContext';
import { History, Trash2, ArrowRight, Clock, CheckCircle2, AlertCircle } from 'lucide-react';

const STATUS_CONFIG = {
  active: { icon: Clock, color: 'text-signal-orange', label: 'In Progress' },
  complete: { icon: CheckCircle2, color: 'text-acid', label: 'Complete' },
  error: { icon: AlertCircle, color: 'text-signal-red', label: 'Error' },
};

export default function HistoryView({ setActiveView }) {
  const { sessions, loadSession, deleteSession, setActiveView: _ } = useVault();

  const handleOpen = async (id) => {
    await loadSession(id);
    setActiveView('pipeline');
  };

  return (
    <div className="flex-1 overflow-y-auto p-6 max-w-3xl mx-auto w-full">
      <div className="flex items-center gap-3 mb-6">
        <History size={18} className="text-gray-500" />
        <p className="font-display font-semibold text-white">Pipeline History</p>
        <span className="font-mono text-xs text-gray-600 bg-ink-800 px-2 py-0.5 rounded">
          {sessions.length} runs
        </span>
      </div>

      {sessions.length === 0 ? (
        <div className="text-center py-20">
          <History size={32} className="text-ink-600 mx-auto mb-3" />
          <p className="text-gray-600 text-sm">No pipeline runs yet.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {sessions.map(s => {
            const status = STATUS_CONFIG[s.status] || STATUS_CONFIG.active;
            const completedStations = s.stations ? Object.values(s.stations).filter(st => st.status === 'complete').length : 0;

            return (
              <div key={s.id}
                className="card hover:border-ink-600 transition-all cursor-pointer group"
                onClick={() => handleOpen(s.id)}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className={`${status.color}`}>
                      <status.icon size={16} />
                    </div>
                    <div>
                      <p className="font-mono text-sm text-white font-medium">
                        {s.seed_keyword || 'Untitled Run'}
                      </p>
                      <div className="flex items-center gap-3 mt-0.5">
                        {s.niche && (
                          <span className="text-gray-600 text-xs">{s.niche}</span>
                        )}
                        <span className="text-gray-700 text-xs font-mono">
                          {new Date(s.created_at).toLocaleDateString('en-US', {
                            month: 'short', day: 'numeric', year: 'numeric'
                          })}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    {/* Station progress dots */}
                    <div className="flex items-center gap-1.5">
                      {[1, 2, 3, 4].map(n => {
                        const st = s.stations?.[n];
                        return (
                          <div key={n}
                            className={`w-2 h-2 rounded-full transition-all
                              ${st?.status === 'complete' ? 'bg-acid' :
                                st?.status === 'running' ? 'bg-signal-orange animate-pulse' :
                                'bg-ink-600'}`}
                            title={`Station ${n}`}
                          />
                        );
                      })}
                    </div>
                    <span className={`badge text-xs font-mono ${
                      s.status === 'complete' ? 'bg-acid/10 text-acid' :
                      s.status === 'error' ? 'bg-signal-red/10 text-signal-red' :
                      'bg-signal-orange/10 text-signal-orange'
                    }`}>
                      {status.label}
                    </span>
                    <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-all">
                      <button
                        onClick={(e) => { e.stopPropagation(); deleteSession(s.id); }}
                        className="p-1.5 hover:bg-signal-red/10 rounded-lg transition-all">
                        <Trash2 size={13} className="text-gray-600 hover:text-signal-red" />
                      </button>
                      <ArrowRight size={14} className="text-gray-500" />
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
