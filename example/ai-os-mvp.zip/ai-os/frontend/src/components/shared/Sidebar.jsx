import { useState } from 'react';
import { useVault } from '../../context/VaultContext';
import {
  Zap, LayoutDashboard, History, Settings,
  Upload, Code2, Plus, ChevronRight, Trash2,
  Clock, CheckCircle2, AlertCircle
} from 'lucide-react';

const NAV = [
  { id: 'pipeline', icon: LayoutDashboard, label: 'Pipeline' },
  { id: 'history', icon: History, label: 'History' },
  { id: 'vault', icon: Upload, label: 'Knowledge Drive' },
  { id: 'prompts', icon: Code2, label: 'Prompt Editor' },
  { id: 'settings', icon: Settings, label: 'Settings' },
];

const STATUS_ICON = {
  active: <Clock size={12} className="text-signal-orange" />,
  complete: <CheckCircle2 size={12} className="text-acid" />,
  error: <AlertCircle size={12} className="text-signal-red" />,
};

export default function Sidebar({ activeView, setActiveView }) {
  const { sessions, activeSession, loadSession, deleteSession, createSession } = useVault();
  const [creating, setCreating] = useState(false);
  const [seedKeyword, setSeedKeyword] = useState('');
  const [niche, setNiche] = useState('');

  const handleCreate = async (e) => {
    e.preventDefault();
    if (!seedKeyword.trim()) return;
    setCreating(false);
    await createSession(seedKeyword.trim(), niche.trim());
    setSeedKeyword('');
    setNiche('');
    setActiveView('pipeline');
  };

  return (
    <aside className="w-64 flex-shrink-0 h-screen bg-ink-900 border-r border-ink-700 flex flex-col overflow-hidden">
      {/* Logo */}
      <div className="flex items-center gap-3 px-5 py-5 border-b border-ink-700">
        <div className="w-8 h-8 bg-acid rounded-lg flex items-center justify-center">
          <Zap size={16} className="text-ink-950" />
        </div>
        <div>
          <p className="font-display font-bold text-sm text-white leading-none">AI-OS</p>
          <p className="font-mono text-xs text-gray-600 leading-none mt-0.5">Content Engine</p>
        </div>
      </div>

      {/* New Session */}
      <div className="px-4 py-3 border-b border-ink-700">
        {creating ? (
          <form onSubmit={handleCreate} className="space-y-2 animate-fade-in">
            <input
              autoFocus
              className="input text-xs py-2"
              placeholder="Seed keyword…"
              value={seedKeyword}
              onChange={e => setSeedKeyword(e.target.value)}
            />
            <input
              className="input text-xs py-2"
              placeholder="Niche / industry…"
              value={niche}
              onChange={e => setNiche(e.target.value)}
            />
            <div className="flex gap-2">
              <button type="submit" className="btn-primary text-xs py-1.5 flex-1">
                <Zap size={12} /> Launch
              </button>
              <button type="button" onClick={() => setCreating(false)}
                className="btn-ghost text-xs py-1.5">
                Cancel
              </button>
            </div>
          </form>
        ) : (
          <button
            onClick={() => setCreating(true)}
            className="w-full flex items-center gap-2 px-3 py-2.5 bg-acid/10 border border-acid/20
              hover:bg-acid/15 hover:border-acid/40 rounded-lg transition-all group">
            <Plus size={14} className="text-acid" />
            <span className="text-acid text-sm font-display font-medium">New Pipeline Run</span>
          </button>
        )}
      </div>

      {/* Nav */}
      <nav className="px-3 py-3 space-y-0.5">
        {NAV.map(item => (
          <button
            key={item.id}
            onClick={() => setActiveView(item.id)}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all
              ${activeView === item.id
                ? 'bg-surface-raised text-white'
                : 'text-gray-500 hover:text-gray-300 hover:bg-surface'}`}>
            <item.icon size={16} />
            <span className="font-body">{item.label}</span>
            {activeView === item.id && (
              <ChevronRight size={14} className="ml-auto text-gray-600" />
            )}
          </button>
        ))}
      </nav>

      {/* Recent Sessions */}
      <div className="flex-1 overflow-y-auto px-3 py-2">
        <p className="label px-2 mb-2">Recent Sessions</p>
        <div className="space-y-1">
          {sessions.slice(0, 10).map(s => (
            <div
              key={s.id}
              onClick={() => { loadSession(s.id); setActiveView('pipeline'); }}
              className={`group flex items-start gap-2 px-3 py-2.5 rounded-lg cursor-pointer transition-all
                ${activeSession?.id === s.id
                  ? 'bg-surface-overlay border border-ink-600'
                  : 'hover:bg-surface'}`}>
              <div className="mt-0.5 flex-shrink-0">
                {STATUS_ICON[s.status] || STATUS_ICON.active}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs text-white font-mono truncate">{s.seed_keyword || 'Untitled'}</p>
                <p className="text-xs text-gray-600 truncate">{s.niche || '—'}</p>
              </div>
              <button
                onClick={(e) => { e.stopPropagation(); deleteSession(s.id); }}
                className="opacity-0 group-hover:opacity-100 p-1 hover:bg-signal-red/10 rounded transition-all">
                <Trash2 size={11} className="text-gray-600 hover:text-signal-red" />
              </button>
            </div>
          ))}
          {sessions.length === 0 && (
            <p className="text-center text-xs text-gray-700 font-mono py-4">
              No sessions yet
            </p>
          )}
        </div>
      </div>
    </aside>
  );
}
