import { useState } from 'react';
import { useVault } from '../../context/VaultContext';
import { X, Save, RotateCcw, Loader2, Code2, AlertCircle, CheckCircle } from 'lucide-react';

const BLOCKS = [
  { key: 'system_block', label: 'System Block', desc: 'Persona & philosophy' },
  { key: 'context_block', label: 'Context Block', desc: 'Data injection template (use {{variable}})' },
  { key: 'logic_block', label: 'Logic Block', desc: 'Step-by-step reasoning workflow' },
  { key: 'constraints_block', label: 'Constraints Block', desc: 'Guardrails & output rules' },
  { key: 'output_schema', label: 'Output Schema', desc: 'JSON schema contract' },
];

export default function PromptEditorModal({ onClose }) {
  const { prompts, updatePrompt, resetPrompts } = useVault();
  const [activePromptId, setActivePromptId] = useState(prompts[0]?.id || 'station_1');
  const [activeBlock, setActiveBlock] = useState('system_block');
  const [edits, setEdits] = useState({});
  const [saving, setSaving] = useState(false);
  const [resetting, setResetting] = useState(false);
  const [saved, setSaved] = useState(false);

  const activePrompt = prompts.find(p => p.id === activePromptId);
  const currentValue = edits[activePromptId]?.[activeBlock]
    ?? activePrompt?.[activeBlock]
    ?? '';

  const handleEdit = (val) => {
    setEdits(prev => ({
      ...prev,
      [activePromptId]: { ...prev[activePromptId], [activeBlock]: val }
    }));
  };

  const handleSave = async () => {
    const promptEdits = edits[activePromptId];
    if (!promptEdits) return;
    setSaving(true);
    try {
      const merged = { ...activePrompt, ...promptEdits };
      await updatePrompt(activePromptId, merged);
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } finally {
      setSaving(false);
    }
  };

  const handleReset = async () => {
    if (!confirm('Reset ALL prompts to defaults? This cannot be undone.')) return;
    setResetting(true);
    try {
      await resetPrompts();
      setEdits({});
    } finally {
      setResetting(false);
    }
  };

  const hasUnsaved = Object.keys(edits[activePromptId] || {}).length > 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-ink-950/80 backdrop-blur-sm">
      <div className="w-full max-w-5xl h-[85vh] bg-ink-900 border border-ink-700 rounded-2xl flex flex-col overflow-hidden animate-slide-up">

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-ink-700">
          <div className="flex items-center gap-3">
            <Code2 size={18} className="text-acid" />
            <div>
              <p className="font-display font-semibold text-white text-sm">Prompt Editor</p>
              <p className="font-mono text-xs text-gray-600">Edit agent prompt blocks. Changes are saved per station.</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={handleReset} disabled={resetting}
              className="btn-ghost text-xs gap-1.5">
              {resetting ? <Loader2 size={13} className="animate-spin" /> : <RotateCcw size={13} />}
              Reset All
            </button>
            <button onClick={handleSave} disabled={saving || !hasUnsaved}
              className="btn-primary text-xs gap-1.5 disabled:opacity-40">
              {saving ? <Loader2 size={13} className="animate-spin" /> :
                saved ? <CheckCircle size={13} /> : <Save size={13} />}
              {saved ? 'Saved!' : 'Save Changes'}
            </button>
            <button onClick={onClose} className="p-2 hover:bg-surface-raised rounded-lg transition-all">
              <X size={16} className="text-gray-500" />
            </button>
          </div>
        </div>

        <div className="flex flex-1 overflow-hidden">
          {/* Station selector */}
          <div className="w-48 border-r border-ink-700 py-4 flex-shrink-0">
            <p className="label px-4 mb-2">Stations</p>
            {prompts.map(p => (
              <button
                key={p.id}
                onClick={() => { setActivePromptId(p.id); setActiveBlock('system_block'); }}
                className={`w-full text-left px-4 py-3 text-sm transition-all
                  ${activePromptId === p.id
                    ? 'bg-surface-raised text-white border-r-2 border-acid'
                    : 'text-gray-500 hover:text-gray-300 hover:bg-surface'}`}>
                <p className="font-mono text-xs">{`Station ${p.station}`}</p>
                <p className="font-body font-medium text-xs mt-0.5 truncate">{p.label}</p>
              </button>
            ))}
          </div>

          {/* Block selector + editor */}
          <div className="flex flex-1 overflow-hidden">
            {/* Block tabs */}
            <div className="w-44 border-r border-ink-700 py-4 flex-shrink-0">
              <p className="label px-4 mb-2">Blocks</p>
              {BLOCKS.map(b => (
                <button
                  key={b.key}
                  onClick={() => setActiveBlock(b.key)}
                  className={`w-full text-left px-4 py-3 transition-all
                    ${activeBlock === b.key
                      ? 'bg-surface-raised text-white'
                      : 'text-gray-500 hover:text-gray-300 hover:bg-surface'}`}>
                  <p className="font-mono text-xs text-current">{b.label}</p>
                  <p className="text-xs text-gray-600 mt-0.5 leading-tight">{b.desc}</p>
                  {edits[activePromptId]?.[b.key] && (
                    <span className="inline-block mt-1 w-1.5 h-1.5 rounded-full bg-signal-orange" />
                  )}
                </button>
              ))}
            </div>

            {/* Editor */}
            <div className="flex-1 flex flex-col overflow-hidden">
              <div className="px-5 py-3 border-b border-ink-700 flex items-center justify-between">
                <div>
                  <p className="font-mono text-xs text-white">{BLOCKS.find(b => b.key === activeBlock)?.label}</p>
                  <p className="font-mono text-xs text-gray-600">{BLOCKS.find(b => b.key === activeBlock)?.desc}</p>
                </div>
                {activeBlock === 'context_block' && (
                  <div className="flex items-center gap-1.5 px-3 py-1.5 bg-signal-blue/10 border border-signal-blue/20 rounded-lg">
                    <AlertCircle size={12} className="text-signal-blue" />
                    <span className="text-signal-blue text-xs font-mono">Use {'{{variable}}'} for dynamic injection</span>
                  </div>
                )}
              </div>
              <textarea
                className="flex-1 bg-ink-950 text-gray-300 font-mono text-xs p-5 resize-none focus:outline-none leading-relaxed"
                value={currentValue}
                onChange={e => handleEdit(e.target.value)}
                spellCheck={false}
                placeholder="Enter prompt block content…"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
