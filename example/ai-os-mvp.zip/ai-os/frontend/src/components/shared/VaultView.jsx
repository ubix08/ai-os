import { Upload } from 'lucide-react';
import StepKnowledgeDrive from '../onboarding/StepKnowledgeDrive';

export default function VaultView() {
  return (
    <div className="flex-1 overflow-y-auto p-6 max-w-2xl mx-auto w-full">
      <div className="flex items-center gap-3 mb-6">
        <Upload size={18} className="text-gray-500" />
        <p className="font-display font-semibold text-white">Knowledge Drive</p>
      </div>
      <div className="card mb-4">
        <p className="text-gray-400 text-sm leading-relaxed">
          Files uploaded here are sent to the Gemini File API and injected into every pipeline agent as context.
          Use this to ground the AI in your actual product documentation, customer research, and brand guidelines.
        </p>
        <div className="flex flex-wrap gap-2 mt-3">
          {['Product specs', 'Customer interviews', 'Brand guidelines', 'Case studies', 'Competitor analysis'].map(tag => (
            <span key={tag} className="badge bg-ink-700 text-gray-500 text-xs font-mono">{tag}</span>
          ))}
        </div>
      </div>
      <StepKnowledgeDrive />
    </div>
  );
}
