import { useVault } from '../../context/VaultContext';
import { Map, FileText, PenSquare, Share2, ChevronRight, Zap } from 'lucide-react';

const STATIONS = [
  { num: 1, label: 'Topical Mapper', icon: Map, color: 'signal-blue' },
  { num: 2, label: 'Brief Architect', icon: FileText, color: 'signal-purple' },
  { num: 3, label: 'Asset Generator', icon: PenSquare, color: 'acid' },
  { num: 4, label: 'Distributor', icon: Share2, color: 'signal-orange' },
];

const COLOR_MAP = {
  'signal-blue': { active: 'bg-signal-blue/10 border-signal-blue/40 text-signal-blue', dot: 'bg-signal-blue' },
  'signal-purple': { active: 'bg-signal-purple/10 border-signal-purple/40 text-signal-purple', dot: 'bg-signal-purple' },
  'acid': { active: 'bg-acid/10 border-acid/40 text-acid', dot: 'bg-acid' },
  'signal-orange': { active: 'bg-signal-orange/10 border-signal-orange/40 text-signal-orange', dot: 'bg-signal-orange' },
};

export default function TopBar({ activeView }) {
  const { activeSession, currentStation, setCurrentStation } = useVault();

  if (activeView !== 'pipeline') return (
    <div className="h-14 bg-ink-900 border-b border-ink-700 flex items-center px-6">
      <p className="font-display font-semibold text-white text-sm capitalize">{activeView}</p>
    </div>
  );

  return (
    <div className="h-14 bg-ink-900 border-b border-ink-700 flex items-center px-6 gap-2 overflow-x-auto">
      {activeSession && (
        <div className="flex items-center gap-1 mr-4">
          <Zap size={12} className="text-acid" />
          <span className="font-mono text-xs text-gray-500 truncate max-w-32">
            {activeSession.seed_keyword}
          </span>
        </div>
      )}

      {STATIONS.map((s, i) => {
        const stationData = activeSession?.stations?.[s.num];
        const isComplete = stationData?.status === 'complete';
        const isActive = currentStation === s.num;
        const isAccessible = activeSession && (
          s.num === 1 ||
          activeSession?.stations?.[s.num - 1]?.status === 'complete'
        );
        const colors = COLOR_MAP[s.color];

        return (
          <div key={s.num} className="flex items-center gap-2 flex-shrink-0">
            <button
              disabled={!isAccessible}
              onClick={() => isAccessible && setCurrentStation(s.num)}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-mono transition-all
                ${isActive && isAccessible ? colors.active :
                  isComplete ? 'bg-ink-800 border-ink-600 text-gray-400' :
                  'border-transparent text-gray-600 hover:text-gray-400 disabled:opacity-30 disabled:cursor-not-allowed'}`}>
              <s.icon size={13} />
              <span>{s.label}</span>
              {isComplete && (
                <span className={`w-1.5 h-1.5 rounded-full ${colors.dot}`} />
              )}
            </button>
            {i < STATIONS.length - 1 && (
              <ChevronRight size={12} className="text-ink-600 flex-shrink-0" />
            )}
          </div>
        );
      })}

      {!activeSession && (
        <p className="text-xs text-gray-600 font-mono ml-2">
          Start a new pipeline run to begin →
        </p>
      )}
    </div>
  );
}
