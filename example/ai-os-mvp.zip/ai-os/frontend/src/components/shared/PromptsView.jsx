import { useState } from 'react';
import { Code2 } from 'lucide-react';
import PromptEditorModal from './PromptEditorModal';

export default function PromptsView() {
  return (
    <div className="flex-1 flex items-center justify-center p-6">
      <div className="text-center space-y-4">
        <div className="w-14 h-14 bg-acid/10 rounded-2xl flex items-center justify-center mx-auto">
          <Code2 size={24} className="text-acid" />
        </div>
        <div>
          <p className="font-display font-semibold text-white">Prompt Editor</p>
          <p className="text-gray-500 text-sm mt-1 max-w-xs">
            Edit the prompt blocks that power each pipeline station. Changes are stored in your personal vault.
          </p>
        </div>
        <PromptEditorModal onClose={() => {}} embedded />
      </div>
    </div>
  );
}
