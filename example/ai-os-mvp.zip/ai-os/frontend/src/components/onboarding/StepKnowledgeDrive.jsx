import { useState, useRef } from 'react';
import { useVault } from '../../context/VaultContext';
import { Upload, File, Trash2, Loader2, AlertCircle, CheckCircle } from 'lucide-react';

const ACCEPTED = ['application/pdf', 'text/plain', 'text/markdown'];
const MAX_MB = 20;

export default function StepKnowledgeDrive() {
  const { files, uploadFile, deleteFile } = useVault();
  const [dragging, setDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState(null);
  const [deletingId, setDeletingId] = useState(null);
  const inputRef = useRef(null);

  const handleFiles = async (fileList) => {
    const file = fileList[0];
    if (!file) return;

    if (!ACCEPTED.includes(file.type) && !file.name.endsWith('.md')) {
      setError('Only PDF, TXT, and Markdown files are supported.');
      return;
    }
    if (file.size > MAX_MB * 1024 * 1024) {
      setError(`File must be under ${MAX_MB}MB.`);
      return;
    }

    setError(null);
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append('file', file);
      await uploadFile(fd);
    } catch (e) {
      setError(e.message);
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async (id) => {
    setDeletingId(id);
    try {
      await deleteFile(id);
    } catch (e) {
      setError(e.message);
    } finally {
      setDeletingId(null);
    }
  };

  const onDrop = (e) => {
    e.preventDefault();
    setDragging(false);
    handleFiles(e.dataTransfer.files);
  };

  const formatSize = (uri) => '—';

  return (
    <div className="space-y-4">
      {/* Drop zone */}
      <div
        onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={onDrop}
        onClick={() => inputRef.current?.click()}
        className={`relative flex flex-col items-center justify-center gap-3 p-8 rounded-xl border-2 border-dashed cursor-pointer transition-all
          ${dragging ? 'border-acid bg-acid/5' : 'border-ink-600 hover:border-ink-500 bg-ink-800/50'}`}>

        <input
          ref={inputRef}
          type="file"
          className="hidden"
          accept=".pdf,.txt,.md"
          onChange={(e) => handleFiles(e.target.files)}
        />

        {uploading ? (
          <>
            <Loader2 size={28} className="text-acid animate-spin" />
            <p className="text-sm text-gray-400">Uploading to Gemini File API…</p>
          </>
        ) : (
          <>
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center
              ${dragging ? 'bg-acid/20' : 'bg-ink-700'}`}>
              <Upload size={22} className={dragging ? 'text-acid' : 'text-gray-500'} />
            </div>
            <div className="text-center">
              <p className="text-sm text-white font-medium">Drop file or click to browse</p>
              <p className="text-xs text-gray-600 mt-1">PDF · TXT · Markdown · Max {MAX_MB}MB</p>
            </div>
          </>
        )}
      </div>

      {/* Error */}
      {error && (
        <div className="flex items-center gap-2 p-3 bg-signal-red/10 border border-signal-red/20 rounded-lg">
          <AlertCircle size={14} className="text-signal-red flex-shrink-0" />
          <p className="text-signal-red text-xs">{error}</p>
        </div>
      )}

      {/* Uploaded files list */}
      {files.length > 0 && (
        <div className="space-y-2">
          <p className="label">Uploaded Files ({files.length})</p>
          {files.map(f => (
            <div key={f.id}
              className="flex items-center gap-3 p-3 bg-ink-800 border border-ink-600 rounded-lg">
              <div className="w-8 h-8 bg-acid/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <File size={14} className="text-acid" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-white truncate font-mono">{f.file_name}</p>
                <p className="text-xs text-gray-600">
                  {f.mime_type} · Uploaded {new Date(f.uploaded_at).toLocaleDateString()}
                </p>
              </div>
              <CheckCircle size={14} className="text-acid flex-shrink-0" />
              <button
                onClick={(e) => { e.stopPropagation(); handleDelete(f.id); }}
                disabled={deletingId === f.id}
                className="p-1.5 hover:bg-signal-red/10 rounded-lg transition-all group">
                {deletingId === f.id
                  ? <Loader2 size={14} className="animate-spin text-gray-500" />
                  : <Trash2 size={14} className="text-gray-600 group-hover:text-signal-red" />}
              </button>
            </div>
          ))}
        </div>
      )}

      {files.length === 0 && !uploading && (
        <p className="text-center text-xs text-gray-600 font-mono py-2">
          No files yet — the OS will use general knowledge until you upload.
        </p>
      )}
    </div>
  );
}
