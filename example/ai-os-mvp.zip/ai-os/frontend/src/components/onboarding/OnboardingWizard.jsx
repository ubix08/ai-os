import { useState } from 'react';
import { useVault } from '../../context/VaultContext';
import {
  ArrowRight, ArrowLeft, Zap, Globe, User, Target,
  Mic, Upload, CheckCircle, Loader2
} from 'lucide-react';
import StepKnowledgeDrive from './StepKnowledgeDrive';

const TONES = [
  { id: 'conversational', label: 'Conversational', opp: 'Academic' },
  { id: 'aggressive', label: 'Aggressive', opp: 'Empathetic' },
  { id: 'technical', label: 'Technical', opp: 'Accessible' },
  { id: 'bold', label: 'Bold', opp: 'Measured' },
  { id: 'data_driven', label: 'Data-Driven', opp: 'Story-Led' },
];

const STEPS = [
  { id: 1, label: 'The Basics', icon: Globe },
  { id: 2, label: 'Value Prop', icon: Target },
  { id: 3, label: 'Voice Engine', icon: Mic },
  { id: 4, label: 'Anti-Persona', icon: User },
  { id: 5, label: 'Knowledge Drive', icon: Upload },
];

export default function OnboardingWizard() {
  const { saveProfile, profile } = useVault();
  const [step, setStep] = useState(1);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    business_name: profile?.business_name || '',
    website_url: profile?.website_url || '',
    linkedin: profile?.linkedin || '',
    twitter: profile?.twitter || '',
    value_prop: profile?.value_prop || '',
    target_audience: profile?.target_audience || '',
    anti_persona: profile?.anti_persona || '',
    brand_tone: profile?.brand_tone || [],
  });

  const set = (key, val) => setForm(p => ({ ...p, [key]: val }));

  const toggleTone = (id) => {
    setForm(p => ({
      ...p,
      brand_tone: p.brand_tone.includes(id)
        ? p.brand_tone.filter(t => t !== id)
        : [...p.brand_tone, id]
    }));
  };

  const handleFinish = async () => {
    setSaving(true);
    try {
      await saveProfile({ ...form, onboarding_done: 1 });
    } finally {
      setSaving(false);
    }
  };

  const canAdvance = () => {
    if (step === 1) return form.business_name.trim().length > 0;
    if (step === 2) return form.value_prop.trim().length > 0 && form.target_audience.trim().length > 0;
    if (step === 3) return form.brand_tone.length > 0;
    if (step === 4) return form.anti_persona.trim().length > 0;
    return true;
  };

  return (
    <div className="min-h-screen bg-ink-950 flex flex-col items-center justify-center p-6 relative overflow-hidden">
      {/* Background grid */}
      <div className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: 'linear-gradient(#C8FF00 1px, transparent 1px), linear-gradient(90deg, #C8FF00 1px, transparent 1px)',
          backgroundSize: '48px 48px'
        }}
      />

      {/* Logo */}
      <div className="mb-10 flex items-center gap-3 relative z-10">
        <div className="w-10 h-10 bg-acid rounded-xl flex items-center justify-center">
          <Zap size={20} className="text-ink-950" />
        </div>
        <span className="font-display font-bold text-xl text-white">AI-OS</span>
        <span className="font-mono text-xs text-gray-600 mt-0.5">/ Context Vault Setup</span>
      </div>

      {/* Step indicator */}
      <div className="flex items-center gap-2 mb-10 relative z-10">
        {STEPS.map((s, i) => (
          <div key={s.id} className="flex items-center gap-2">
            <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-mono transition-all
              ${step === s.id ? 'bg-acid text-ink-950 font-semibold' :
                step > s.id ? 'bg-acid/20 text-acid' : 'bg-ink-800 text-gray-600'}`}>
              {step > s.id ? <CheckCircle size={12} /> : <s.icon size={12} />}
              <span className="hidden sm:inline">{s.label}</span>
            </div>
            {i < STEPS.length - 1 && (
              <div className={`w-8 h-px ${step > s.id ? 'bg-acid/40' : 'bg-ink-700'}`} />
            )}
          </div>
        ))}
      </div>

      {/* Card */}
      <div className="w-full max-w-lg bg-surface border border-ink-700 rounded-2xl p-8 relative z-10 animate-slide-up">

        {/* Step 1 - Basics */}
        {step === 1 && (
          <div className="space-y-5">
            <div>
              <h2 className="font-display font-bold text-2xl text-white mb-1">
                Let's build your Context Vault
              </h2>
              <p className="text-gray-500 text-sm">
                This powers every AI agent in your OS. Takes 3 minutes.
              </p>
            </div>
            <div>
              <label className="label">Business Name *</label>
              <input className="input" placeholder="e.g. Acme Studio" value={form.business_name}
                onChange={e => set('business_name', e.target.value)} />
            </div>
            <div>
              <label className="label">Website URL</label>
              <input className="input" placeholder="https://yourdomain.com" value={form.website_url}
                onChange={e => set('website_url', e.target.value)} />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="label">LinkedIn handle</label>
                <input className="input" placeholder="@yourhandle" value={form.linkedin}
                  onChange={e => set('linkedin', e.target.value)} />
              </div>
              <div>
                <label className="label">Twitter / X handle</label>
                <input className="input" placeholder="@yourhandle" value={form.twitter}
                  onChange={e => set('twitter', e.target.value)} />
              </div>
            </div>
          </div>
        )}

        {/* Step 2 - Value Prop */}
        {step === 2 && (
          <div className="space-y-5">
            <div>
              <h2 className="font-display font-bold text-2xl text-white mb-1">What do you actually do?</h2>
              <p className="text-gray-500 text-sm">Be brutally specific. Generic answers produce generic content.</p>
            </div>
            <div>
              <label className="label">Your Value Proposition *</label>
              <textarea className="textarea" rows={4}
                placeholder="e.g. I help B2B SaaS founders reduce churn by mapping user activation failures using session replay analysis — not surveys."
                value={form.value_prop} onChange={e => set('value_prop', e.target.value)} />
            </div>
            <div>
              <label className="label">Target Audience *</label>
              <textarea className="textarea" rows={3}
                placeholder="e.g. Series A SaaS founders with 10-50 person teams, $1M-$5M ARR, struggling with retention after month 3."
                value={form.target_audience} onChange={e => set('target_audience', e.target.value)} />
            </div>
          </div>
        )}

        {/* Step 3 - Voice Engine */}
        {step === 3 && (
          <div className="space-y-5">
            <div>
              <h2 className="font-display font-bold text-2xl text-white mb-1">Define your brand voice</h2>
              <p className="text-gray-500 text-sm">Select all that apply. These are injected into every content agent.</p>
            </div>
            <div className="space-y-3">
              {TONES.map(tone => (
                <button key={tone.id} onClick={() => toggleTone(tone.id)}
                  className={`w-full flex items-center justify-between px-4 py-3 rounded-xl border transition-all
                    ${form.brand_tone.includes(tone.id)
                      ? 'bg-acid/10 border-acid/40 text-acid'
                      : 'bg-ink-800 border-ink-600 text-gray-400 hover:border-ink-500'}`}>
                  <span className="font-mono text-sm font-medium">{tone.label}</span>
                  <span className="text-xs opacity-50">vs {tone.opp}</span>
                  {form.brand_tone.includes(tone.id) && <CheckCircle size={16} />}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Step 4 - Anti-Persona */}
        {step === 4 && (
          <div className="space-y-5">
            <div>
              <h2 className="font-display font-bold text-2xl text-white mb-1">Who is NOT your customer?</h2>
              <p className="text-gray-500 text-sm">
                This prevents the AI from writing watered-down, everyone-is-a-target content.
              </p>
            </div>
            <div>
              <label className="label">Anti-Persona *</label>
              <textarea className="textarea" rows={5}
                placeholder="e.g. NOT for:&#10;- Enterprise companies with dedicated analytics teams&#10;- Founders who haven't launched yet&#10;- Businesses under $500k ARR (can't afford to act on insights)&#10;- Non-technical audiences who won't understand session replay"
                value={form.anti_persona} onChange={e => set('anti_persona', e.target.value)} />
            </div>
            <div className="bg-signal-orange/10 border border-signal-orange/20 rounded-lg p-4">
              <p className="text-signal-orange text-xs font-mono">
                💡 The AI will actively avoid writing content that appeals to these segments,
                keeping every asset razor-focused on your real buyers.
              </p>
            </div>
          </div>
        )}

        {/* Step 5 - Knowledge Drive */}
        {step === 5 && (
          <div className="space-y-5">
            <div>
              <h2 className="font-display font-bold text-2xl text-white mb-1">Upload your knowledge base</h2>
              <p className="text-gray-500 text-sm">
                PDFs, brand guides, product specs, customer interviews. The AI will use these to write with precision.
              </p>
            </div>
            <StepKnowledgeDrive />
          </div>
        )}

        {/* Navigation */}
        <div className="flex items-center justify-between mt-8 pt-6 border-t border-ink-700">
          <button
            onClick={() => setStep(s => s - 1)}
            disabled={step === 1}
            className="btn-ghost disabled:opacity-30">
            <ArrowLeft size={16} /> Back
          </button>

          {step < 5 ? (
            <button
              onClick={() => setStep(s => s + 1)}
              disabled={!canAdvance()}
              className="btn-primary">
              Continue <ArrowRight size={16} />
            </button>
          ) : (
            <button
              onClick={handleFinish}
              disabled={saving}
              className="btn-primary">
              {saving ? <Loader2 size={16} className="animate-spin" /> : <Zap size={16} />}
              {saving ? 'Activating OS…' : 'Launch AI-OS'}
            </button>
          )}
        </div>
      </div>

      {/* Progress bar */}
      <div className="w-full max-w-lg mt-4 relative z-10">
        <div className="h-1 bg-ink-800 rounded-full overflow-hidden">
          <div
            className="h-full bg-acid rounded-full transition-all duration-500"
            style={{ width: `${(step / 5) * 100}%` }}
          />
        </div>
        <p className="text-center text-xs text-gray-600 mt-2 font-mono">Step {step} of 5</p>
      </div>
    </div>
  );
}
