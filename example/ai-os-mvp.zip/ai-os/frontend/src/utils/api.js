const BASE = import.meta.env.VITE_WORKER_URL || '/api';

async function request(method, path, body, isFormData = false) {
  const opts = {
    method,
    headers: isFormData ? {} : { 'Content-Type': 'application/json' },
  };
  if (body) {
    opts.body = isFormData ? body : JSON.stringify(body);
  }

  const res = await fetch(`${BASE}${path}`, opts);
  const data = await res.json();

  if (!res.ok) {
    throw new Error(data.error || `Request failed: ${res.status}`);
  }
  return data;
}

export const api = {
  // Profile
  getProfile: () => request('GET', '/vault/profile'),
  saveProfile: (data) => request('POST', '/vault/profile', data),

  // Prompts
  getPrompts: () => request('GET', '/vault/prompts'),
  updatePrompt: (id, data) => request('PUT', `/vault/prompts/${id}`, data),
  resetPrompts: () => request('POST', '/vault/prompts/reset'),

  // Files
  getFiles: () => request('GET', '/vault/files'),
  uploadFile: (formData) => request('POST', '/vault/files', formData, true),
  deleteFile: (id) => request('DELETE', `/vault/files/${id}`),

  // Sessions
  getSessions: () => request('GET', '/pipeline/sessions'),
  createSession: (data) => request('POST', '/pipeline/sessions', data),
  getSession: (id) => request('GET', `/pipeline/sessions/${id}`),
  deleteSession: (id) => request('DELETE', `/pipeline/sessions/${id}`),

  // Station execution
  executeStation: (sessionId, station) =>
    request('POST', `/pipeline/sessions/${sessionId}/station/${station}`),
};
