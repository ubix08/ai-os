import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { api } from '../utils/api';

const VaultContext = createContext(null);

export function VaultProvider({ children }) {
  const [profile, setProfile] = useState(null);
  const [files, setFiles] = useState([]);
  const [sessions, setSessions] = useState([]);
  const [prompts, setPrompts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Active pipeline state
  const [activeSession, setActiveSession] = useState(null);
  const [currentStation, setCurrentStation] = useState(1);
  const [stationLoading, setStationLoading] = useState(false);
  const [stationError, setStationError] = useState(null);

  const loadInitialData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [profileData, filesData, sessionsData, promptsData] = await Promise.all([
        api.getProfile(),
        api.getFiles(),
        api.getSessions(),
        api.getPrompts(),
      ]);
      setProfile(profileData);
      setFiles(filesData);
      setSessions(sessionsData);
      setPrompts(promptsData);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadInitialData(); }, [loadInitialData]);

  const saveProfile = async (data) => {
    await api.saveProfile(data);
    setProfile(prev => ({ ...prev, ...data }));
  };

  const uploadFile = async (formData) => {
    const result = await api.uploadFile(formData);
    setFiles(prev => [result, ...prev]);
    return result;
  };

  const deleteFile = async (id) => {
    await api.deleteFile(id);
    setFiles(prev => prev.filter(f => f.id !== id));
  };

  const updatePrompt = async (id, data) => {
    await api.updatePrompt(id, data);
    setPrompts(prev => prev.map(p => p.id === id ? { ...p, ...data } : p));
  };

  const resetPrompts = async () => {
    await api.resetPrompts();
    const fresh = await api.getPrompts();
    setPrompts(fresh);
  };

  const createSession = async (seedKeyword, niche) => {
    const session = await api.createSession({ seed_keyword: seedKeyword, niche });
    const full = await api.getSession(session.id);
    setSessions(prev => [full, ...prev]);
    setActiveSession(full);
    setCurrentStation(1);
    setStationError(null);
    return full;
  };

  const loadSession = async (id) => {
    const full = await api.getSession(id);
    setActiveSession(full);
    // Determine which station to resume from
    const completedStations = Object.keys(full.stations || {}).map(Number);
    const nextStation = completedStations.length > 0
      ? Math.min(Math.max(...completedStations) + 1, 4)
      : 1;
    setCurrentStation(nextStation);
    setStationError(null);
  };

  const executeStation = async (stationNum) => {
    if (!activeSession) return;
    setStationLoading(true);
    setStationError(null);
    try {
      const result = await api.executeStation(activeSession.id, stationNum);
      // Refresh session to get updated station data
      const updated = await api.getSession(activeSession.id);
      setActiveSession(updated);
      setSessions(prev => prev.map(s => s.id === updated.id ? updated : s));
      setCurrentStation(Math.min(stationNum + 1, 4));
      return result;
    } catch (e) {
      setStationError(e.message);
      throw e;
    } finally {
      setStationLoading(false);
    }
  };

  const deleteSession = async (id) => {
    await api.deleteSession(id);
    setSessions(prev => prev.filter(s => s.id !== id));
    if (activeSession?.id === id) {
      setActiveSession(null);
      setCurrentStation(1);
    }
  };

  return (
    <VaultContext.Provider value={{
      // State
      profile, files, sessions, prompts, loading, error,
      activeSession, currentStation, stationLoading, stationError,
      // Actions
      saveProfile, uploadFile, deleteFile,
      updatePrompt, resetPrompts,
      createSession, loadSession, executeStation, deleteSession,
      setCurrentStation, setActiveSession,
      reload: loadInitialData,
    }}>
      {children}
    </VaultContext.Provider>
  );
}

export const useVault = () => {
  const ctx = useContext(VaultContext);
  if (!ctx) throw new Error('useVault must be used within VaultProvider');
  return ctx;
};
