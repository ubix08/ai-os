import { useState } from 'react';
import { VaultProvider, useVault } from './context/VaultContext';
import OnboardingWizard from './components/onboarding/OnboardingWizard';
import Sidebar from './components/shared/Sidebar';
import TopBar from './components/shared/TopBar';
import PipelineShell from './components/pipeline/PipelineShell';
import HistoryView from './components/shared/HistoryView';
import VaultView from './components/shared/VaultView';
import SettingsView from './components/shared/SettingsView';
import PromptEditorModal from './components/shared/PromptEditorModal';
import { Loader2, Code2 } from 'lucide-react';

function AppShell() {
  const { profile, loading, error } = useVault();
  const [activeView, setActiveView] = useState('pipeline');
  const [showPromptEditor, setShowPromptEditor] = useState(false);

  if (loading) {
    return (
      <div className="min-h-screen bg-ink-950 flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <Loader2 size={28} className="text-acid animate-spin" />
          <p className="font-mono text-sm text-gray-500">Initializing AI-OS…</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-ink-950 flex items-center justify-center p-6">
        <div className="text-center space-y-3">
          <p className="font-display font-bold text-signal-red text-xl">Connection Error</p>
          <p className="text-gray-500 text-sm max-w-sm">{error}</p>
          <p className="font-mono text-xs text-gray-700">
            Make sure your Cloudflare Worker is running and VITE_WORKER_URL is set.
          </p>
          <button onClick={() => window.location.reload()}
            className="btn-ghost text-sm mt-2">
            Retry
          </button>
        </div>
      </div>
    );
  }

  // Show onboarding if not completed
  if (!profile?.onboarding_done) {
    return <OnboardingWizard />;
  }

  return (
    <div className="flex h-screen bg-ink-950 overflow-hidden">
      <Sidebar activeView={activeView} setActiveView={setActiveView} />

      <div className="flex-1 flex flex-col overflow-hidden">
        <TopBar activeView={activeView} />

        {/* Prompt editor toggle */}
        <div className="absolute top-3 right-4 z-40">
          <button
            onClick={() => setShowPromptEditor(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-ink-800 border border-ink-600
              hover:border-ink-500 rounded-lg text-xs text-gray-500 hover:text-gray-300 transition-all font-mono">
            <Code2 size={12} /> Prompt Editor
          </button>
        </div>

        {/* Main content */}
        <div className="flex-1 flex overflow-hidden">
          {activeView === 'pipeline' && <PipelineShell />}
          {activeView === 'history' && <HistoryView setActiveView={setActiveView} />}
          {activeView === 'vault' && <VaultView />}
          {activeView === 'settings' && <SettingsView />}
          {activeView === 'prompts' && (
            <div className="flex-1 flex items-center justify-center">
              <button onClick={() => setShowPromptEditor(true)} className="btn-primary">
                <Code2 size={16} /> Open Prompt Editor
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Prompt Editor Modal */}
      {showPromptEditor && (
        <PromptEditorModal onClose={() => setShowPromptEditor(false)} />
      )}
    </div>
  );
}

export default function App() {
  return (
    <VaultProvider>
      <AppShell />
    </VaultProvider>
  );
}
