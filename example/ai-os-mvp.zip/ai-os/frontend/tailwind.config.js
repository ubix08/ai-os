/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['Syne', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
        body: ['DM Sans', 'sans-serif'],
      },
      colors: {
        ink: {
          950: '#080B10',
          900: '#0D1117',
          800: '#161B24',
          700: '#1E2530',
          600: '#2A3340',
        },
        acid: {
          DEFAULT: '#C8FF00',
          dim: '#A3D100',
          muted: '#3D4A00',
        },
        signal: {
          blue: '#00D4FF',
          orange: '#FF6B2C',
          purple: '#9B6DFF',
          red: '#FF3B5C',
        },
        surface: {
          DEFAULT: '#161B24',
          raised: '#1E2530',
          overlay: '#2A3340',
        }
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'slide-up': 'slideUp 0.4s cubic-bezier(0.16, 1, 0.3, 1)',
        'fade-in': 'fadeIn 0.3s ease-out',
        'shimmer': 'shimmer 1.5s infinite',
      },
      keyframes: {
        slideUp: {
          '0%': { transform: 'translateY(12px)', opacity: 0 },
          '100%': { transform: 'translateY(0)', opacity: 1 },
        },
        fadeIn: {
          '0%': { opacity: 0 },
          '100%': { opacity: 1 },
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        }
      }
    },
  },
  plugins: [],
}
